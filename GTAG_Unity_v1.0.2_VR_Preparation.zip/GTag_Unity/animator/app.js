import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { clone as skeletonClone } from 'three/addons/utils/SkeletonUtils.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const $ = id => document.getElementById(id);
const loader = new GLTFLoader();
const exporter = new GLTFExporter();
let renderer, scene, camera, orbit, gizmo, grid;
let modelRoot = null, modelSourceBuffer = null, modelFileName = '', rigNodes = [], bones = [], selectedObject = null;
let restPose = new Map(), nodeByName = new Map();
let project = null, activeClipId = null, playhead = 0, isPlaying = false, lastTick = 0;
let timelineWidth = 700, saveTimer = null, toastTimer = null, graphConnectMode = false, connectFrom = null;
let currentPreset = 'chase', currentIntensity = 1.45, currentUnpredictability = .78, currentFreeze = .32;
let isLoading = false;

const DB_NAME = 'GTAGAnimatorStudio';
const DB_VERSION = 1;
let dbPromise;
function openDB(){
  if(!('indexedDB' in window)) return Promise.resolve(null);
  if(!dbPromise) dbPromise = new Promise((resolve,reject)=>{
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => { const db=req.result; if(!db.objectStoreNames.contains('projects')) db.createObjectStore('projects',{keyPath:'id'}); };
    req.onsuccess=()=>resolve(req.result); req.onerror=()=>reject(req.error);
  }).catch(()=>null);
  return dbPromise;
}
async function dbPut(p){ const db=await openDB(); if(!db) return; return new Promise((resolve,reject)=>{const tx=db.transaction('projects','readwrite');tx.objectStore('projects').put(p);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);}); }
async function dbGetAll(){ const db=await openDB(); if(!db) return []; return new Promise(resolve=>{const q=db.transaction('projects','readonly').objectStore('projects').getAll();q.onsuccess=()=>resolve(q.result||[]);q.onerror=()=>resolve([]);}); }
async function dbDelete(id){const db=await openDB();if(!db)return;return new Promise(resolve=>{const tx=db.transaction('projects','readwrite');tx.objectStore('projects').delete(id);tx.oncomplete=resolve;tx.onerror=resolve;});}

function uid(){ return (crypto?.randomUUID?.() || ('id_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2))); }
function toast(msg){ const el=$('toast'); el.textContent=msg; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),3000); }
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function activeClip(){return project?.clips?.find(c=>c.id===activeClipId)||null;}
function setSaveStatus(s){$('saveStatus').innerHTML=`<span class="statusDot"></span>${s}`;}

function initThree(){
  if(renderer) return;
  const host=$('viewport');
  scene=new THREE.Scene(); scene.background=new THREE.Color(0x111820); scene.fog=new THREE.Fog(0x111820,18,42);
  camera=new THREE.PerspectiveCamera(48,1,.05,1500); camera.position.set(3.6,2.7,5.8);
  renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,preserveDrawingBuffer:false});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2)); renderer.outputColorSpace=THREE.SRGBColorSpace; renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.08;
  host.appendChild(renderer.domElement);
  orbit=new OrbitControls(camera,renderer.domElement); orbit.enableDamping=true; orbit.dampingFactor=.07; orbit.target.set(0,1,0); orbit.minDistance=1.1; orbit.maxDistance=30;
  scene.add(new THREE.HemisphereLight(0xaec4d6,0x20232d,2.15));
  const key=new THREE.DirectionalLight(0xffe4c2,2.3); key.position.set(4,8,5); scene.add(key);
  const fill=new THREE.DirectionalLight(0x64a8cb,1.0); fill.position.set(-5,3,-4); scene.add(fill);
  const rim=new THREE.PointLight(0x4ac9b0,9,14); rim.position.set(-2,2.8,2); scene.add(rim);
  grid=new THREE.GridHelper(30,30,0x43515e,0x283541); grid.position.y=0; scene.add(grid);
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(100,100),new THREE.MeshStandardMaterial({color:0x141b22,roughness:.92,metalness:.05})); floor.rotation.x=-Math.PI/2; floor.position.y=-.012; floor.name='EditorGround'; scene.add(floor);
  gizmo=new TransformControls(camera,renderer.domElement); gizmo.setSize(.82); scene.add(gizmo.getHelper());
  gizmo.addEventListener('dragging-changed',e=>{orbit.enabled=!e.value;});
  gizmo.addEventListener('objectChange',()=>{updateInspector();updatePlayheadDisplay();});
  window.addEventListener('resize',resizeRenderer); resizeRenderer();
  renderer.setAnimationLoop(renderLoop);
}
function resizeRenderer(){if(!renderer)return;const r=$('viewport').getBoundingClientRect();if(r.width<2||r.height<2)return;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.updateProjectionMatrix();}
function renderLoop(now){
  if(isPlaying&&activeClip()){
    const dt=Math.min(.05,(now-lastTick)/1000||0); playhead+=dt;
    const c=activeClip(); const len=Math.max(.1,c.duration||1);
    if(playhead>len){if(c.loop)playhead%=len;else{playhead=len;isPlaying=false;setPlayButton();}}
    applyClipAt(playhead); updateTimelinePlayhead();
  }
  lastTick=now; orbit?.update(); renderer?.render(scene,camera);
}

function emptyProject(name='Untitled Animation Project'){
  return {id:uid(),name,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),modelName:'',modelBuffer:null,clips:[],states:[],transitions:[],settings:{fps:24,chaos:1.45,unpredictability:.78,freeze:.32}};
}
function showLauncher(){ isPlaying=false; $('editor').classList.add('hidden'); $('launcher').classList.remove('hidden'); renderProjectCards(); }
function showEditor(){ $('launcher').classList.add('hidden'); $('editor').classList.remove('hidden'); initThree(); resizeRenderer(); }
function renderProjectCards(){
  const host=$('recentProjects');
  dbGetAll().then(items=>{
    host.innerHTML='';
    if(!items.length){host.innerHTML='<div class="trackEmpty" style="grid-column:1/-1">No saved projects yet. Choose a template below to create your first animation project.</div>';return;}
    for(const p of items.sort((a,b)=>(b.updatedAt||'').localeCompare(a.updatedAt||''))){
      const el=document.createElement('button');el.className='projectCard';
      const date=p.updatedAt?new Date(p.updatedAt).toLocaleDateString():'';
      el.innerHTML=`<div class="thumb">${p.modelName?'👹':'🦴'}</div><b>${escapeHtml(p.name||'Untitled project')}</b><small>${escapeHtml(p.modelName||'No rig imported')} · ${(p.clips||[]).length} clips · ${date}</small><div style="display:flex;gap:6px;margin-top:auto"><span class="tiny">OPEN PROJECT ↗</span><span style="margin-left:auto;color:#e98789;font-size:10px" data-delete="${p.id}">Delete</span></div>`;
      el.addEventListener('click',e=>{const del=e.target.closest('[data-delete]');if(del){e.stopPropagation();if(confirm('Delete this saved project?'))dbDelete(p.id).then(renderProjectCards);return;}openProject(p);});
      host.appendChild(el);
    }
  });
}

async function createProject(template,name){
  const p=emptyProject(name|| (template==='empty'?'Untitled Rig Project':template==='gtag'?'Gorilla Rig Lab':template==='hurting'?'The Hurting':template==='original'?'Original Monke':'Monster Lab'));
  project=p; modelSourceBuffer=null; modelFileName='';
  showEditor();
  clearRig();
  if(template==='monster'||template==='gtag'||template==='hurting'||template==='original'){
    const path=template==='gtag'?'player/monke':template==='hurting'?'monsters/hurting':template==='original'?'original':'monsters/timmy';
    const buffer=await fetchSample(path); await loadGLBBuffer(buffer,path.split('/').pop()+'.glb',{sample:true});
    createStarterPack(template==='gtag'?'Gorilla':template==='hurting'?'Hurting':template==='original'?'Original':'Timmy');
  }
  updateProjectTitle(); refreshAll(); scheduleAutosave();
  toast(template==='empty'?'New empty project created':'Monster rig loaded with starter animation clips');
}
async function openProject(p){
  project={...p,clips:p.clips||[],states:p.states||[],transitions:p.transitions||[],settings:p.settings||{}};
  showEditor(); clearRig();
  if(project.modelBuffer){await loadGLBBuffer(project.modelBuffer,project.modelName||'Imported model.glb',{fromProject:true});}
  updateProjectTitle();refreshAll();
  if(activeClipId&&!activeClip())activeClipId=project.clips[0]?.id||null;
  if(activeClip())selectClip(activeClipId); else updateTimeline();
  toast('Project opened');
}
function updateProjectTitle(){$('projectName').textContent=project?.name||'Untitled';}
function clearRig(){
  if(modelRoot){gizmo?.detach();scene.remove(modelRoot);modelRoot=null;}
  modelSourceBuffer=null;modelFileName='';rigNodes=[];bones=[];restPose.clear();nodeByName.clear();selectedObject=null;activeClipId=null;playhead=0;isPlaying=false;
  $('modelPlaceholder').classList.remove('hidden');$('rigStatus').textContent='NO RIG';$('nodeCount').textContent='0 NODES';renderHierarchy();renderInspector();renderTimeline();renderClipList();renderGraph();
}
function uniqueNames(root){const seen=new Map();root.traverse(o=>{if(o===root)return;let base=(o.name||'Node').trim()||'Node';const n=(seen.get(base)||0)+1;seen.set(base,n);if(n>1)o.name=base+'__'+n;else o.name=base;});}
function captureRestPose(){
  restPose.clear(); nodeByName.clear(); rigNodes=[]; bones=[];
  modelRoot.traverse(o=>{
    rigNodes.push(o); if(o.isBone)bones.push(o);
    if(o!==modelRoot){nodeByName.set(o.name,o);}
    restPose.set(o.name,{position:o.position.clone(),quaternion:o.quaternion.clone(),scale:o.scale.clone()});
  });
  nodeByName.set(modelRoot.name,modelRoot);
}
async function loadGLBBuffer(buffer,fileName,{sample=false,fromProject=false}={}){
  isLoading=true; toast('Loading rig…');
  try{
    const bytes=buffer instanceof ArrayBuffer?buffer:buffer.buffer.slice(buffer.byteOffset,buffer.byteOffset+buffer.byteLength);
    const gltf=await new Promise((resolve,reject)=>loader.parse(bytes,'',resolve,reject));
    clearRig(); modelRoot=new THREE.Group(); modelRoot.name='MonsterRoot'; modelRoot.add(gltf.scene); scene.add(modelRoot);
    uniqueNames(modelRoot); captureRestPose(); modelSourceBuffer=bytes.slice(0);modelFileName=fileName;
    project.modelBuffer=modelSourceBuffer;project.modelBase64=null;project.modelName=fileName;
    $('modelPlaceholder').classList.add('hidden');$('rigStatus').textContent=`${bones.length} BONES · ${gltf.scene.children.length} ROOT NODES`;
    if(!fromProject && !project.clips.length && gltf.animations?.length){
      for(const native of gltf.animations){const converted=convertNativeClip(native);if(converted)project.clips.push(converted);}
    }
    if(!project.clips.length&&!fromProject&&!sample){project.clips=[];}
    selectedObject=modelRoot; gizmo.attach(modelRoot); setGizmoMode('rotate');
    renderHierarchy(); renderInspector(); renderClipList(); renderTimeline(); focusSelected();
    if(activeClipId==null&&project.clips.length)activeClipId=project.clips[0].id;
    if(activeClip())selectClip(activeClipId);
    scheduleAutosave(); toast(`Loaded ${fileName} · ${bones.length} bones`);
  }catch(err){console.error(err);toast('GLB import failed: '+(err.message||err));throw err;}
  finally{isLoading=false;}
}
function convertNativeClip(native){
  const clip={id:uid(),name:native.name||'Imported Animation',duration:Math.max(.1,native.duration||1),fps:24,loop:true,source:'imported',tracks:{}};
  for(const track of native.tracks||[]){
    const dot=track.name.lastIndexOf('.'); if(dot<1)continue;
    const nodeName=track.name.slice(0,dot),prop=track.name.slice(dot+1);
    if(!['position','quaternion','scale'].includes(prop))continue;
    const node=nodeByName.get(nodeName);if(!node)continue;
    const width=prop==='quaternion'?4:3;const vals=track.values;const times=track.times;
    if(!vals||!times||!times.length)continue;
    clip.tracks[nodeName] ||= {};
    clip.tracks[nodeName][prop]=Array.from(times,(t,i)=>({t:Number(t),v:Array.from(vals.slice(i*width,i*width+width),Number)}));
  }
  return Object.keys(clip.tracks).length?clip:null;
}
function loadSample(){
  const path=project?.name?.toLowerCase().includes('gorilla')?'player/monke.glb':'monsters/timmy.glb';
  fetchSample(path.replace('.glb','')).then(async b=>{await loadGLBBuffer(b,path.split('/').pop(),{sample:true});createStarterPack(path.includes('monke')?'Gorilla':'Timmy');refreshAll();scheduleAutosave();}).catch(e=>toast('Sample model could not load: '+e.message));
}

function captureObjTransform(o){return {position:o.position.toArray(),quaternion:o.quaternion.toArray(),scale:o.scale.toArray()};}
function restoreAllRest(){
  if(!modelRoot)return;
  modelRoot.traverse(o=>{const r=restPose.get(o.name);if(!r)return;o.position.copy(r.position);o.quaternion.copy(r.quaternion);o.scale.copy(r.scale);});
}
function interpKeys(keys,t,quat=false){
  if(!keys?.length)return null;
  const sorted=keys;
  if(t<=sorted[0].t)return sorted[0].v;
  if(t>=sorted[sorted.length-1].t)return sorted[sorted.length-1].v;
  let lo=0;while(lo<sorted.length-1&&sorted[lo+1].t<t)lo++;
  const a=sorted[lo],b=sorted[lo+1],u=(t-a.t)/Math.max(1e-6,b.t-a.t);
  if(quat){const qa=new THREE.Quaternion(...a.v),qb=new THREE.Quaternion(...b.v);qa.slerp(qb,u);return qa.toArray();}
  return a.v.map((v,i)=>v+(b.v[i]-v)*u);
}
function applyClipAt(t){
  const c=activeClip();if(!c||!modelRoot)return;
  restoreAllRest();
  for(const [name,channels] of Object.entries(c.tracks||{})){
    const o=nodeByName.get(name);if(!o)continue;
    if(channels.position){const v=interpKeys(channels.position,t);if(v)o.position.fromArray(v);}
    if(channels.quaternion){const v=interpKeys(channels.quaternion,t,true);if(v)o.quaternion.fromArray(v);}
    if(channels.scale){const v=interpKeys(channels.scale,t);if(v)o.scale.fromArray(v);}
  }
  updateInspectorValuesOnly();
}
function makeThreeClip(data){
  const tracks=[];
  for(const [nodeName,channels] of Object.entries(data.tracks||{})){
    for(const prop of ['position','quaternion','scale']){
      const keys=channels[prop];if(!keys?.length)continue;
      const ordered=[...keys].sort((a,b)=>a.t-b.t); const times=[],values=[];
      for(const k of ordered){times.push(k.t);values.push(...k.v);}
      const Track=prop==='quaternion'?THREE.QuaternionKeyframeTrack:THREE.VectorKeyframeTrack;
      tracks.push(new Track(`${nodeName}.${prop}`,times,values));
    }
  }
  return new THREE.AnimationClip(data.name||'Animation',data.duration||1,tracks);
}

function classifyBone(name){
  const s=name.toLowerCase();
  if(/jaw|head|skull|eye/.test(s))return 'head';
  if(/neck/.test(s))return 'neck';
  if(/spine|chest|torso|body|hips|pelvis/.test(s))return 'spine';
  if(/shoulder|upper.?arm|arm|forearm|elbow/.test(s))return 'arm';
  if(/hand|finger|thumb|wrist/.test(s))return 'hand';
  if(/thigh|leg|knee|calf|shin|foot|toe/.test(s))return 'leg';
  return 'other';
}
function smoothNoise(t,seed){const x=t*4.3+seed;const i=Math.floor(x),f=x-i;const a=Math.sin(i*127.1+seed*311)*43758.5453;const b=Math.sin((i+1)*127.1+seed*311)*43758.5453;const va=(a-Math.floor(a))*2-1,vb=(b-Math.floor(b))*2-1;const u=f*f*(3-2*f);return va+(vb-va)*u;}
function seededRand(seed){let s=seed>>>0;return ()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
function generateChaosClip(name,kind,{duration=5,fps=18,intensity=1.45,unpredictability=.78,freeze=.32,seed=0x73a991}={}){
  if(!modelRoot)throw new Error('Load a rig before generating animations.');
  const clip={id:uid(),name,duration,fps,loop:kind!=='jumpscare',source:'generated',preset:kind,tracks:{}};
  const rand=seededRand(seed>>>0), boneList=bones.length?bones:[modelRoot];
  const frameCount=Math.max(2,Math.ceil(duration*fps));
  const baseIntensity=Math.max(.1,intensity);
  function addKey(obj,prop,t,v){const n=obj.name;clip.tracks[n] ||= {};clip.tracks[n][prop] ||= [];clip.tracks[n][prop].push({t:Number(t.toFixed(4)),v});}
  const rootRest=restPose.get(modelRoot.name);
  for(let frame=0;frame<=frameCount;frame++){
    const t=duration*frame/frameCount;
    const freezePhase=(t*1.15+seed*.001)%1;
    const frozen=freeze>0 && freezePhase<freeze*.55 ? .06 : 1;
    const snapWave=Math.pow(Math.max(0,Math.sin(t*5.2+seed*.002)),12);
    const fuzz=smoothNoise(t,seed*.0003);
    const lunge=kind==='jumpscare'?Math.exp(-Math.pow((t-duration*.34)/(duration*.075),2)) + .38*Math.exp(-Math.pow((t-duration*.77)/(duration*.06),2)):0;
    const searchTap=kind==='search'?Math.pow(Math.max(0,Math.sin(t*3.1+1.2)),16):0;
    const idleSnap=kind==='idle'?Math.pow(Math.max(0,Math.sin(t*1.6+.4)),18):0;
    const crawlPulse=kind==='crawl'?Math.sin(t*8.5):0;
    const spasm=kind==='pain'?Math.pow(Math.max(0,Math.sin(t*2.3+seed*.001)),22)+.7*Math.pow(Math.max(0,Math.sin(t*3.7+seed*.002+1.3)),30):0;const trem=kind==='pain'?Math.sin(t*41+seed*.01)*.05+Math.sin(t*29)*.03:0;
    const phaseBase=(seed%97)*.13;
    for(let bi=0;bi<boneList.length;bi++){
      const bone=boneList[bi],cat=bone===modelRoot?'root':classifyBone(bone.name),side=/\.l|_l|left/i.test(bone.name)?-1:/\.r|_r|right/i.test(bone.name)?1:(bi%2?1:-1);
      const phase=phaseBase+bi*.83, wave=Math.sin(t*(kind==='search'?2.2:kind==='idle'?1.1:7.4)+phase), wave2=Math.sin(t*(kind==='search'?1.1:10.3)+phase*1.7);
      const n=smoothNoise(t+bi*.13,seed+bi*17), rnd=(rand()-.5)*2;
      const chaotic=(.25+unpredictability*.8)*(n*.45+rnd*.13+Math.sin(t*18+phase)*.12);
      let x=0,y=0,z=0;
      if(kind==='chase'){
        if(cat==='head'){x=.24*wave2+.38*snapWave+chaotic*.34;y=.58*Math.sin(t*2.6+phase)+.45*snapWave+chaotic*.38;z=.28*Math.sin(t*6.3+phase)+chaotic*.24;}
        else if(cat==='neck'){x=.16*wave2+.24*snapWave;y=.28*Math.sin(t*3.3+phase);z=.16*Math.sin(t*5+phase);}
        else if(cat==='spine'){x=.19+.12*wave+.24*snapWave;y=.13*Math.sin(t*4+phase);z=.17*Math.sin(t*5+phase);}
        else if(cat==='arm'){x=.68*Math.sin(t*8.2+phase)+.42*snapWave+chaotic*.38;y=.22*Math.sin(t*6+phase);z=side*(.72+.38*Math.sin(t*7.1+phase)+.3*snapWave);}
        else if(cat==='hand'){x=.35*wave2+chaotic*.5;y=.2*Math.sin(t*11+phase);z=side*(.3+.28*Math.sin(t*9+phase));}
        else if(cat==='leg'){x=.42*Math.sin(t*7.4+phase)+.16*wave2;y=.12*Math.sin(t*4+phase);z=.12*Math.sin(t*7+phase);}
        else{x=.18*wave+chaotic*.3;y=.15*wave2;z=.18*Math.sin(t*4+phase);}
      }else if(kind==='search'){
        if(cat==='head'){x=-.30+.16*wave2;y=.95*Math.sin(t*1.55+phase)+side*.22*searchTap+Math.sign(wave2)*.35*snapWave;z=.2*Math.sin(t*1.8+phase);}
        else if(cat==='neck'){x=-.16+.12*wave;y=.42*Math.sin(t*1.3+phase);z=.14*Math.sin(t*1.7+phase);}
        else if(cat==='spine'){x=-.34+.08*wave;y=.12*Math.sin(t*1.1+phase);z=.1*Math.sin(t*1.2+phase);}
        else if(cat==='arm'){x=.18*Math.sin(t*2.5+phase)+side*.32*searchTap;y=.14*Math.sin(t*1.5+phase);z=side*(.46+.13*wave2)+side*.24*searchTap;}
        else if(cat==='hand'){x=.45*searchTap+.12*wave;y=.2*Math.sin(t*3+phase);z=side*.34;}
        else if(cat==='leg'){x=.12*wave;y=.1*wave2;z=.08*wave;}
        else{x=.14*wave;y=.15*wave2;z=.12*wave;}
      }else if(kind==='jumpscare'){
        if(cat==='head'){x=.56*lunge+.15*wave2;y=.55*Math.sin(t*12+phase)+.4*lunge+chaotic*.3;z=.28*Math.sin(t*9+phase);}
        else if(cat==='neck'){x=.2+.46*lunge;y=.16*wave;z=.12*wave2;}
        else if(cat==='spine'){x=.28*lunge+.06*wave;y=.1*wave2;z=.12*wave;}
        else if(cat==='arm'){x=-.25+1.15*lunge+.25*wave2;y=side*.42*lunge;z=side*(1.45*lunge+.34+.2*wave);}
        else if(cat==='hand'){x=.4*lunge+.2*wave;y=.25*wave2;z=side*(.8*lunge+.2);}
        else if(cat==='leg'){x=-.15*lunge+.2*wave;y=.1*wave2;z=.12*wave;}
        else{x=.26*lunge+.15*wave;y=.18*wave2;z=.15*wave;}
      }else if(kind==='pain'){
        if(cat==='head'){x=.5-1.25*spasm+trem*2;y=.35*Math.sin(t*.9+phase)+.15*Math.sin(t*4.6)+trem;z=.5*Math.sin(t*.6+phase)+.35*spasm;}
        else if(cat==='neck'){x=.32-.7*spasm+trem;y=.12*Math.sin(t*1.1+phase);z=.18*Math.sin(t*.7+phase);}
        else if(cat==='spine'){x=.62-1.0*spasm+trem;y=.14*Math.sin(t*1.2+phase);z=.18*Math.sin(t*.8+phase)+.1*spasm;}
        else if(cat==='arm'){x=-.95+1.3*spasm+trem*2;y=side*(.35-.3*spasm);z=side*(.95+.6*spasm)+trem;}
        else if(cat==='hand'){x=.55+trem*3-.4*spasm;y=.2*Math.sin(t*6+phase);z=side*.45;}
        else if(cat==='leg'){x=.25*Math.sin(t*1.4+phase)+trem;y=.08*wave;z=.08*wave2;}
        else{x=.15*wave+trem;y=.1*wave2;z=.1*wave;}
      }else if(kind==='crawl'){
        if(cat==='head'){x=.52+.18*wave2;y=.38*Math.sin(t*4+phase);z=.3*Math.sin(t*5+phase);}
        else if(cat==='spine'){x=.55+.14*wave;y=.1*wave2;z=.2*wave;}
        else if(cat==='arm'||cat==='hand'){x=.45*Math.sin(t*8+phase)+side*.35* crawlPulse;y=.1*wave2;z=side*(.8+.45*Math.sin(t*8.5+phase));}
        else if(cat==='leg'){x=.55*Math.sin(t*8.5+phase);y=.15*wave;z=.18*wave2;}
        else{x=.2*wave;y=.2*wave2;z=.15*wave;}
      }else{
        if(cat==='head'){x=.08*wave+.38*idleSnap+chaotic*.18;y=.22*Math.sin(t*.7+phase)+.42*idleSnap+chaotic*.24;z=.12*Math.sin(t*1.3+phase);}
        else if(cat==='spine'){x=.05+.08*wave+.18*idleSnap;y=.08*wave2;z=.08*wave;}
        else if(cat==='arm'){x=.08*wave+.24*idleSnap;y=.1*wave2;z=side*(.28+.14*wave)+side*.2*idleSnap;}
        else if(cat==='hand'){x=.16*wave2+.2*idleSnap;y=.16*wave;z=.15*wave2;}
        else{x=.06*wave;y=.08*wave2;z=.05*wave;}
      }
      x=(x+chaotic*.32)*baseIntensity*frozen; y=(y+chaotic*.30)*baseIntensity*frozen; z=(z+chaotic*.26)*baseIntensity*frozen;
      const rest=restPose.get(bone.name);const offset=new THREE.Quaternion().setFromEuler(new THREE.Euler(x,y,z,'XYZ'));
      const q=rest?rest.quaternion.clone().multiply(offset):offset;
      addKey(bone,'quaternion',t,q.toArray());
    }
    if(rootRest){
      let px=rootRest.position.x,py=rootRest.position.y,pz=rootRest.position.z,rx=0,ry=0,rz=0;
      if(kind==='chase'){py+=Math.abs(Math.sin(t*7.5))*0.11*baseIntensity*frozen;px+=Math.sin(t*3.1)*.06*baseIntensity;rx=.08*Math.sin(t*7)+.13*snapWave;ry=.08*Math.sin(t*2.8);rz=.09*Math.sin(t*6.8);}
      else if(kind==='search'){py+=.018*Math.sin(t*2);rx=.08*Math.sin(t*1.4);ry=.04*Math.sin(t*1.3);}
      else if(kind==='jumpscare'){py+=.34*lunge;pz-=.62*lunge;rx=-.12*lunge;}
      else if(kind==='crawl'){py-=.12;rx=.12*Math.sin(t*8.5);}
      else if(kind==='pain'){py+=-.06+.12*spasm+trem*.4;rx=.18-.35*spasm+trem;rz=.1*Math.sin(t*.8)+trem;}
      else{ry=.06*Math.sin(t*.6);rz=.025*Math.sin(t*1.4);}
      addKey(modelRoot,'position',t,[px,py,pz]);
      const q=rootRest.quaternion.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(rx,ry,rz)));
      addKey(modelRoot,'quaternion',t,q.toArray());
    }
  }
  return clip;
}
function createStarterPack(label){
  const imported=project.clips.filter(c=>c.source==='imported');
  project.clips=[...imported];project.states=[];project.transitions=[];
  const seeds=[0x42ab91,0x128ac3,0x5a113f,0x9e3779,0x556677,0x1b873a];
  const pack=[
    ['CHASE — FERAL','chase',{duration:5.2,intensity:1.55,unpredictability:.86,freeze:.24}],
    ['SEARCH — LISTENING','search',{duration:5.4,intensity:1.15,unpredictability:.62,freeze:.4}],
    ['JUMPSCARE — LUNGE','jumpscare',{duration:3.4,intensity:1.7,unpredictability:.74,freeze:.12}],
    ['IDLE — UNCANNY','idle',{duration:5.8,intensity:.72,unpredictability:.56,freeze:.55}],
    ['CRAWL — SPIDER','crawl',{duration:5.0,intensity:1.4,unpredictability:.8,freeze:.2}],
    ['PAIN — WRITHING','pain',{duration:6.0,intensity:1.2,unpredictability:.5,freeze:.1}]
  ];if(label==='Hurting')pack.unshift(pack.pop());
  for(let i=0;i<pack.length;i++){
    const [name,kind,opts]=pack[i];const c=generateChaosClip(name,kind,{...opts,fps:18,seed:seeds[i]});project.clips.push(c);
    project.states.push({id:uid(),name,clipId:c.id,x:30+i*190,y:53+(i%2)*48});
  }
  project.transitions=[{id:uid(),from:project.states[0].id,to:project.states[1].id,condition:'Target lost'},{id:uid(),from:project.states[1].id,to:project.states[0].id,condition:'Target seen'},{id:uid(),from:project.states[0].id,to:project.states[2].id,condition:'Attack'},{id:uid(),from:project.states[2].id,to:project.states[3].id,condition:'Scare finished'},{id:uid(),from:project.states[0].id,to:project.states[4].id,condition:'Crawler mode'},{id:uid(),from:project.states[4].id,to:project.states[0].id,condition:'Stand up'}];
  activeClipId=project.clips[imported.length]?.id||project.clips[0].id;playhead=0;applyClipAt(0);renderClipList();renderGraph();renderTimeline();
}

function renderHierarchy(){
  const host=$('hierarchy');if(!host)return;
  if(!modelRoot){host.innerHTML='<div class="trackEmpty">No model loaded yet.</div>';return;}
  let html=`<div class="treeRow ${selectedObject===modelRoot?'selected':''}" data-node="${escapeHtml(modelRoot.name)}"><span class="treeIcon">▣</span><b>${escapeHtml(modelRoot.name)}</b></div>`;
  const list=bones.slice().sort((a,b)=>a.name.localeCompare(b.name));
  if(list.length){html+='<div class="treeGroup">'+list.map(b=>`<div class="treeRow ${selectedObject===b?'selected':''}" data-node="${escapeHtml(b.name)}"><span class="treeIcon">◈</span>${escapeHtml(b.name)}</div>`).join('')+'</div>';}
  const meshCount=rigNodes.filter(o=>o.isMesh).length;
  html+=`<div class="tiny" style="padding:9px 5px">${bones.length} bones · ${meshCount} mesh nodes</div>`;
  host.innerHTML=html;
  host.querySelectorAll('[data-node]').forEach(el=>el.addEventListener('click',()=>{const o=nodeByName.get(el.dataset.node);if(o)selectObject(o);}));
  $('nodeCount').textContent=`${rigNodes.length} NODES`;
}
function selectObject(o){selectedObject=o;gizmo.detach();if(o){gizmo.attach(o);}
  document.querySelectorAll('.treeRow').forEach(el=>el.classList.toggle('selected',el.dataset.node===o?.name));
  renderHierarchy();renderInspector();
}
function setGizmoMode(mode){gizmo?.setMode(mode);$('moveModeBtn').classList.toggle('active',mode==='translate');$('rotateModeBtn').classList.toggle('active',mode==='rotate');}
function focusSelected(){if(!selectedObject)return;const box=new THREE.Box3().setFromObject(selectedObject);if(box.isEmpty())return;const center=box.getCenter(new THREE.Vector3());orbit.target.copy(center);const size=box.getSize(new THREE.Vector3()).length();const dir=camera.position.clone().sub(orbit.target).normalize();camera.position.copy(center).add(dir.multiplyScalar(Math.max(2,size*1.3)));orbit.update();}
function resetPose(){restoreAllRest();playhead=0;updateInspector();updateTimelinePlayhead();}

function renderInspector(){
  const host=$('inspector');if(!host)return;
  if(!modelRoot){host.innerHTML='<div class="trackEmpty">Import a rigged .glb to start animating. The inspector will show transform and bone controls.</div>'; $('selectedObjectType').textContent='—';return;}
  const o=selectedObject||modelRoot;const isBone=o.isBone; $('selectedObjectType').textContent=isBone?'BONE':o===modelRoot?'RIG ROOT':o.isMesh?'MESH':'NODE';
  const pos=o.position,rot=new THREE.Euler().setFromQuaternion(o.quaternion),sc=o.scale;
  const val=(n)=>Number(n).toFixed(3);
  host.innerHTML=`<div class="inspectorSection"><div class="inspectorTitle">SELECTED ${isBone?'BONE':'OBJECT'}</div><div style="font-size:13px;font-weight:800;margin-bottom:5px">${escapeHtml(o.name)}</div><div class="tiny">${isBone?'Skeleton bone transform':'Local transform'} · ${isBone?'Keyframe this bone':'Keyframe model root'}</div></div>
  <div class="inspectorSection"><div class="inspectorTitle">POSITION</div><div class="threeCols">${['x','y','z'].map((k,i)=>`<label><span class="fieldLabel">${k.toUpperCase()}</span><input data-transform="position" data-axis="${i}" type="number" step="0.01" value="${val(pos.getComponent(i))}"></label>`).join('')}</div></div>
  <div class="inspectorSection"><div class="inspectorTitle">ROTATION · DEGREES</div><div class="threeCols">${[rot.x,rot.y,rot.z].map((v,i)=>`<label><span class="fieldLabel">${['X','Y','Z'][i]}°</span><input data-transform="rotation" data-axis="${i}" type="number" step="1" value="${(v*180/Math.PI).toFixed(1)}"></label>`).join('')}</div></div>
  <div class="inspectorSection"><div class="inspectorTitle">SCALE</div><div class="threeCols">${['x','y','z'].map((k,i)=>`<label><span class="fieldLabel">${k.toUpperCase()}</span><input data-transform="scale" data-axis="${i}" type="number" step="0.01" value="${val(sc.getComponent(i))}"></label>`).join('')}</div></div>
  <div class="inspectorSection"><div class="inspectorTitle">ANIMATION TOOLS</div><button class="primary wideBtn" id="inspectorKeyBtn">◆ Key selected transform &nbsp; <span class="tiny">I</span></button><button class="wideBtn" id="inspectorChaosBtn">⚡ Generate chaotic animation…</button><button class="wideBtn" id="inspectorRestoreBtn">↺ Restore rest pose</button><div class="inspectorNote">A keyframe stores this object's position, rotation and scale at the current playhead time. For monster motion, use the chaos generator to animate the whole skeleton at once.</div></div>`;
  host.querySelectorAll('[data-transform]').forEach(inp=>inp.addEventListener('change',()=>{
    const prop=inp.dataset.transform,axis=Number(inp.dataset.axis),n=Number(inp.value);if(!Number.isFinite(n))return;
    if(prop==='position')o.position.setComponent(axis,n);
    else if(prop==='scale')o.scale.setComponent(axis,Math.max(.001,n));
    else{const e=new THREE.Euler().setFromQuaternion(o.quaternion);e['xyz'[axis]]=n*Math.PI/180;o.quaternion.setFromEuler(e);}
    updateInspectorValuesOnly();
  }));
  $('inspectorKeyBtn').onclick=insertKeyframe;$('inspectorChaosBtn').onclick=openChaosModal;$('inspectorRestoreBtn').onclick=()=>{const r=restPose.get(o.name);if(r){o.position.copy(r.position);o.quaternion.copy(r.quaternion);o.scale.copy(r.scale);updateInspector();}};
}
function updateInspectorValuesOnly(){
  const o=selectedObject||modelRoot;if(!o)return;
  $('inspector')?.querySelectorAll('[data-transform]').forEach(inp=>{
    const prop=inp.dataset.transform,axis=Number(inp.dataset.axis);let val;
    if(prop==='position')val=o.position.getComponent(axis);
    else if(prop==='scale')val=o.scale.getComponent(axis);
    else{const e=new THREE.Euler().setFromQuaternion(o.quaternion);val=e['xyz'[axis]]*180/Math.PI;}
    if(document.activeElement!==inp)inp.value=Number(val).toFixed(prop==='rotation'?1:3);
  });
}
function updateInspector(){renderInspector();}

function insertKeyframe(){
  const c=activeClip(),o=selectedObject||modelRoot;if(!c){toast('Create or select an animation clip first');return;}if(!o){toast('Select a rig object first');return;}
  const keyName=o.name;c.tracks[keyName] ||= {};
  const transform=captureObjTransform(o);
  for(const [prop,v] of [['position',transform.position],['quaternion',transform.quaternion],['scale',transform.scale]]){
    const keys=c.tracks[keyName][prop] ||= [];const existing=keys.findIndex(k=>Math.abs(k.t-playhead)<.0001);const item={t:Number(playhead.toFixed(4)),v};if(existing>=0)keys[existing]=item;else keys.push(item);keys.sort((a,b)=>a.t-b.t);
  }
  c.duration=Math.max(c.duration,playhead+.05);refreshTimeline();scheduleAutosave();toast(`Keyframe added · ${keyName}`);
}
function deleteKeyframe(){
  const c=activeClip(),o=selectedObject||modelRoot;if(!c||!o)return;
  const ch=c.tracks[o.name];if(!ch)return;let removed=0;
  for(const prop of Object.keys(ch)){const i=ch[prop].findIndex(k=>Math.abs(k.t-playhead)<.025);if(i>=0){ch[prop].splice(i,1);removed++;}}
  if(!Object.keys(ch).some(k=>ch[k]?.length))delete c.tracks[o.name];
  refreshTimeline();scheduleAutosave();toast(removed?'Keyframe removed':'No keyframe at the playhead');
}
function renderClipList(){
  const host=$('clipList');if(!host)return;
  if(!project?.clips?.length){host.innerHTML='<div class="trackEmpty">No clips yet. Generate a monster animation or create a blank clip.</div>';return;}
  host.innerHTML=project.clips.map(c=>`<div class="clipCard ${c.id===activeClipId?'selected':''}" data-clip="${c.id}"><div class="clipIcon">${c.source==='generated'?'⚡':'▶'}</div><div class="clipText"><b>${escapeHtml(c.name)}</b><small>${Number(c.duration).toFixed(1)}s · ${Object.keys(c.tracks||{}).length} tracks</small></div><span class="clipDots" title="Clip actions">⋯</span></div>`).join('');
  host.querySelectorAll('[data-clip]').forEach(el=>el.addEventListener('click',()=>selectClip(el.dataset.clip)));
}
function selectClip(id){
  const c=project.clips.find(x=>x.id===id);if(!c)return;activeClipId=id;isPlaying=false;playhead=0;
  $('durationInput').value=Number(c.duration).toFixed(2);$('fpsInput').value=String(c.fps||24);$('loopInput').checked=!!c.loop;
  applyClipAt(0);setPlayButton();renderClipList();renderTimeline();renderGraph();updateTimelinePlayhead();
}
function createBlankClip(){
  const name=prompt('Animation clip name:','New Animation');if(!name)return;
  const c={id:uid(),name,duration:5,fps:24,loop:true,source:'keyframed',tracks:{}};project.clips.push(c);selectClip(c.id);scheduleAutosave();toast('New blank clip created');
}
function activeClipDurationChange(){const c=activeClip();if(!c)return;c.duration=Math.max(.25,Math.min(60,Number($('durationInput').value)||5));c.fps=Math.max(1,Number($('fpsInput').value)||24);c.loop=$('loopInput').checked;playhead=Math.min(playhead,c.duration);refreshTimeline();scheduleAutosave();}
function refreshTimeline(){renderClipList();renderTimeline();updateTimelinePlayhead();}
function renderTimeline(){
  const names=$('trackNames'),rows=$('trackRows'),ruler=$('ruler');const c=activeClip();
  if(!c){names.innerHTML='<div class="trackEmpty">No active clip</div>';rows.innerHTML='';ruler.innerHTML='';updateTimelinePlayhead();return;}
  const len=Math.max(.25,c.duration||5);timelineWidth=Math.max(620,Math.ceil(len*135));ruler.style.width=timelineWidth+'px';rows.style.width=timelineWidth+'px';const rulerArea=document.querySelector('.rulerArea');rulerArea.style.width=timelineWidth+'px';rulerArea.style.flex=`0 0 ${timelineWidth}px`;
  const tickStep=len<=4?.25:len<=9?.5:1;let ticks='';for(let t=0;t<=len+.0001;t+=tickStep){ticks+=`<div class="tick" style="left:${(t/len)*100}%">${t.toFixed(tickStep<1?2:0)}s</div>`;}ruler.innerHTML=ticks;
  const all=[modelRoot,...bones].filter(Boolean);if(!modelRoot){names.innerHTML='<div class="trackEmpty">Load a rig first</div>';rows.innerHTML='';return;}
  const currentTracks=Object.keys(c.tracks||{});
  const list=all.filter(o=>o===modelRoot||o.isBone);
  names.innerHTML=list.map(o=>`<div class="trackName ${selectedObject===o?'active':''}" data-track="${escapeHtml(o.name)}"><span class="channelDot"></span>${escapeHtml(o===modelRoot?'MonsterRoot':o.name)}</div>`).join('');
  rows.innerHTML=list.map(o=>{
    const tr=c.tracks?.[o.name]||{};const keyTimes=[...new Set(['position','quaternion','scale'].flatMap(p=>(tr[p]||[]).map(k=>k.t)))].sort((a,b)=>a-b);
    return `<div class="trackRow ${selectedObject===o?'active':''}" data-trackrow="${escapeHtml(o.name)}">${keyTimes.map(t=>`<span class="keyDiamond" data-keytime="${t}" style="left:${Math.max(0,Math.min(100,t/len*100))}%" title="${t.toFixed(2)}s"></span>`).join('')}</div>`;
  }).join('');
  names.querySelectorAll('[data-track]').forEach(el=>el.addEventListener('click',()=>{const o=nodeByName.get(el.dataset.track);if(o)selectObject(o);}));
  rows.querySelectorAll('[data-trackrow]').forEach(el=>{el.addEventListener('click',e=>{const o=nodeByName.get(el.dataset.trackrow);if(o)selectObject(o);const key=e.target.closest('[data-keytime]');if(key){pausePlayback();playhead=Number(key.dataset.keytime);applyClipAt(playhead);updateTimelinePlayhead();}});});
  const scrubAt=e=>{const rect=ruler.getBoundingClientRect();pausePlayback();playhead=Math.max(0,Math.min(len,(e.clientX-rect.left)/rect.width*len));applyClipAt(playhead);updateTimelinePlayhead();};
  ruler.onpointerdown=e=>{e.preventDefault();ruler.setPointerCapture?.(e.pointerId);scrubAt(e);};
  ruler.onpointermove=e=>{if(e.buttons===1)scrubAt(e);};
  $('timeReadout').textContent=`${playhead.toFixed(2)} / ${len.toFixed(2)}s`;
  updateTimelinePlayhead();
}
function updateTimelinePlayhead(){
  const c=activeClip();const len=Math.max(.25,c?.duration||5);const pct=Math.max(0,Math.min(100,playhead/len*100));$('playhead').style.left=`${pct}%`;$('timeReadout').textContent=`${playhead.toFixed(2)} / ${len.toFixed(2)}s`;
}
function updatePlayheadDisplay(){if(!isPlaying){updateTimelinePlayhead();}}
function setPlayButton(){$('playBtn').textContent=isPlaying?'Ⅱ Pause':'▶ Play';$('playBtn').classList.toggle('primary',!isPlaying);}
function pausePlayback(){isPlaying=false;setPlayButton();}
function togglePlayback(){if(!activeClip()){toast('Select an animation clip first');return;}if(playhead>=activeClip().duration)playhead=0;isPlaying=!isPlaying;lastTick=performance.now();setPlayButton();}
function stopPlayback(){isPlaying=false;playhead=0;applyClipAt(0);setPlayButton();updateTimelinePlayhead();}

function renderGraph(){
  const host=$('graphNodes'),svg=$('graphEdges');if(!host||!svg)return;host.innerHTML='';
  const area=$('graphArea');const w=area.clientWidth||800,h=area.clientHeight||150;svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.innerHTML='<defs><marker id="arrowHead" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L6,3 z" fill="#8ea3b6"/></marker></defs>';
  if(!project?.states?.length){host.innerHTML='<div class="trackEmpty" style="position:absolute;left:18px;top:48px">Add an Animator state from the active animation clip.</div>';return;}
  project.states.forEach(st=>{
    const c=project.clips.find(x=>x.id===st.clipId);const node=document.createElement('div');node.className='graphNode'+(c?.id===activeClipId?' selected':'');node.style.left=(st.x||30)+'px';node.style.top=(st.y||35)+'px';node.dataset.state=st.id;
    node.innerHTML=`<div class="nodeTop" style="background:${c?.preset==='jumpscare'?'#b65e54':c?.preset==='search'?'#b78e4a':c?.preset==='idle'?'#608caa':'#48a17e'}"></div><div class="nodeTitle">${escapeHtml(st.name)}</div><div class="nodeSub">${escapeHtml(c?.name||'No clip assigned')}</div>`;
    node.addEventListener('click',e=>{e.stopPropagation();handleGraphNodeClick(st);});
    node.addEventListener('mousedown',e=>{if(e.button!==0)return;const rect=area.getBoundingClientRect();const offsetX=e.clientX-rect.left-st.x,offsetY=e.clientY-rect.top-st.y;const startX=e.clientX,startY=e.clientY;let moved=false;const mm=ev=>{if(Math.abs(ev.clientX-startX)+Math.abs(ev.clientY-startY)>3)moved=true;st.x=Math.max(0,ev.clientX-rect.left-offsetX);st.y=Math.max(0,ev.clientY-rect.top-offsetY);node.style.left=st.x+'px';node.style.top=st.y+'px';drawGraphEdges();};const up=()=>{document.removeEventListener('mousemove',mm);document.removeEventListener('mouseup',up);if(moved)scheduleAutosave();};document.addEventListener('mousemove',mm);document.addEventListener('mouseup',up);});
    host.appendChild(node);
  });
  drawGraphEdges();
}
function drawGraphEdges(){
  const svg=$('graphEdges'),area=$('graphArea');if(!svg||!area)return;const w=area.clientWidth||800,h=area.clientHeight||150;svg.setAttribute('viewBox',`0 0 ${w} ${h}`);let html='<defs><marker id="arrowHead" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L6,3 z" fill="#8ea3b6"/></marker></defs>';
  for(const tr of project?.transitions||[]){const a=project.states.find(s=>s.id===tr.from),b=project.states.find(s=>s.id===tr.to);if(!a||!b)continue;const x1=a.x+146,y1=a.y+29,x2=b.x,y2=b.y+29,mid=(x1+x2)/2;html+=`<path d="M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}" fill="none" stroke="#8298a9" stroke-width="1.6" marker-end="url(#arrowHead)"/><text x="${mid}" y="${(y1+y2)/2-5}" fill="#8395a3" font-size="9" text-anchor="middle">${escapeHtml(tr.condition||'')}</text>`;}
  svg.innerHTML=html;
}
function handleGraphNodeClick(st){
  if(graphConnectMode){
    if(!connectFrom){connectFrom=st.id;toast('Choose the destination state');return;}
    if(connectFrom!==st.id){project.transitions.push({id:uid(),from:connectFrom,to:st.id,condition:'Transition'});}
    graphConnectMode=false;connectFrom=null;$('connectBtn').classList.remove('active');renderGraph();scheduleAutosave();return;
  }
  const c=project.clips.find(x=>x.id===st.clipId);if(c)selectClip(c.id);project.states.forEach(s=>s.active=s.id===st.id);renderGraph();
}
function addStateFromActive(){const c=activeClip();if(!c){toast('Choose a clip first');return;}const name=prompt('Animator state name:',c.name);if(!name)return;const i=project.states.length;project.states.push({id:uid(),name,clipId:c.id,x:35+(i%4)*180,y:35+Math.floor(i/4)*65});renderGraph();scheduleAutosave();}
function toggleConnect(){graphConnectMode=!graphConnectMode;connectFrom=null;$('connectBtn').classList.toggle('active',graphConnectMode);toast(graphConnectMode?'Click a start state, then a destination state':'State connection cancelled');}
function autoLayoutGraph(){project.states.forEach((s,i)=>{s.x=28+(i%4)*190;s.y=28+Math.floor(i/4)*72;});renderGraph();scheduleAutosave();}

function openModal(html){$('modalContent').innerHTML=html;$('modalShade').classList.remove('hidden');}
function closeModal(){$('modalShade').classList.add('hidden');}
function openChaosModal(){
  currentPreset='chase';currentIntensity=Number(project.settings?.chaos??1.45);currentUnpredictability=Number(project.settings?.unpredictability??.78);currentFreeze=Number(project.settings?.freeze??.32);
  openModal(`<h2>⚡ Chaotic animation generator</h2><p>Generate a complete monster animation across its rigged bones. This creates real editable keyframes and a GLB-exportable animation clip.</p><div class="modalGrid">
  <button class="preset selected" data-preset="chase"><b>CHASE · FERAL</b><small>Sudden starts, flailing arms, heavy head snaps, uneven hops and stop-start bursts.</small></button>
  <button class="preset" data-preset="search"><b>SEARCH · LISTENING</b><small>Hunched posture, sharp head scans, sniffing motions and irregular hand taps.</small></button>
  <button class="preset" data-preset="jumpscare"><b>JUMPSCARE · LUNGE</b><small>Freeze, explosive forward lunge, arms thrown wide and violent head movement.</small></button>
  <button class="preset" data-preset="idle"><b>IDLE · UNCANNY</b><small>Almost still, with tiny twitches, long pauses and sudden unnatural snaps.</small></button>
  <button class="preset" data-preset="crawl"><b>CRAWL · SPIDER</b><small>Low body posture, alternating arm pulls and skittering limb movement.</small></button>
  <button class="preset" data-preset="pain"><b>PAIN · WRITHING</b><small>Doubled over, hands clutching its head, constant shaking and violent spasms that throw it backwards.</small></button>
  </div>
  <label class="fieldLabel">CLIP NAME</label><input id="chaosName" value="CHASE — FERAL" style="width:100%">
  <div class="sliderRow"><label>Intensity</label><input id="chaosIntensity" type="range" min="0.3" max="2.5" value="${currentIntensity}" step="0.05"><output id="chaosIntensityVal">${currentIntensity.toFixed(2)}</output></div>
  <div class="sliderRow"><label>Unpredictability</label><input id="chaosUnpredictability" type="range" min="0" max="1" value="${currentUnpredictability}" step="0.01"><output id="chaosUnpredictabilityVal">${currentUnpredictability.toFixed(2)}</output></div>
  <div class="sliderRow"><label>Freeze / stutter</label><input id="chaosFreeze" type="range" min="0" max="0.9" value="${currentFreeze}" step="0.01"><output id="chaosFreezeVal">${currentFreeze.toFixed(2)}</output></div>
  <div class="fieldRow"><label>Duration (seconds)</label><input id="chaosDuration" type="number" min="1" max="20" step=".5" value="5"></div>
  <div class="fieldRow"><label>Keyframe rate</label><select id="chaosFps"><option value="12">12 FPS · chunky</option><option value="18" selected>18 FPS · balanced</option><option value="24">24 FPS · smooth</option></select></div>
  <div class="modalActions"><button id="cancelChaosBtn">Cancel</button><button id="generatePackBtn">Generate horror pack</button><button id="generateChaosBtn" class="primary">Generate clip</button></div>`);
  const presetNames={chase:'CHASE — FERAL',search:'SEARCH — LISTENING',jumpscare:'JUMPSCARE — LUNGE',idle:'IDLE — UNCANNY',crawl:'CRAWL — SPIDER',pain:'PAIN — WRITHING'};
  document.querySelectorAll('[data-preset]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-preset]').forEach(x=>x.classList.toggle('selected',x===b));currentPreset=b.dataset.preset;$('chaosName').value=presetNames[currentPreset];}));
  for(const [id,out] of [['chaosIntensity','chaosIntensityVal'],['chaosUnpredictability','chaosUnpredictabilityVal'],['chaosFreeze','chaosFreezeVal']])$(id).addEventListener('input',e=>$(out).textContent=Number(e.target.value).toFixed(2));
  $('cancelChaosBtn').onclick=closeModal;$('generateChaosBtn').onclick=()=>{try{project.settings={...(project.settings||{}),chaos:Number($('chaosIntensity').value),unpredictability:Number($('chaosUnpredictability').value),freeze:Number($('chaosFreeze').value)};const c=generateChaosClip($('chaosName').value.trim()||'Chaotic Animation',currentPreset,{duration:Number($('chaosDuration').value)||5,fps:Number($('chaosFps').value)||18,intensity:Number($('chaosIntensity').value),unpredictability:Number($('chaosUnpredictability').value),freeze:Number($('chaosFreeze').value),seed:Math.floor(Math.random()*1e9)});project.clips.push(c);addGraphStateFor(c);selectClip(c.id);closeModal();scheduleAutosave();toast('Chaotic animation generated across the rig');}catch(e){toast(e.message);}};
  $('generatePackBtn').onclick=()=>{const settings={duration:5,fps:Number($('chaosFps').value)||18,intensity:Number($('chaosIntensity').value),unpredictability:Number($('chaosUnpredictability').value),freeze:Number($('chaosFreeze').value)};project.settings={...(project.settings||{}),chaos:settings.intensity,unpredictability:settings.unpredictability,freeze:settings.freeze};const pack=[['CHASE — FERAL','chase'],['SEARCH — LISTENING','search'],['JUMPSCARE — LUNGE','jumpscare'],['IDLE — UNCANNY','idle'],['CRAWL — SPIDER','crawl'],['PAIN — WRITHING','pain']];for(const [name,kind] of pack){const c=generateChaosClip(name,kind,{...settings,duration:kind==='jumpscare'?3.5:5,seed:Math.floor(Math.random()*1e9)});project.clips.push(c);addGraphStateFor(c);}selectClip(project.clips[project.clips.length-6].id);closeModal();scheduleAutosave();toast('Horror animation pack generated · 6 clips added');};
}
function addGraphStateFor(c){const i=project.states.length;project.states.push({id:uid(),name:c.name,clipId:c.id,x:28+(i%4)*190,y:30+Math.floor(i/4)*70});}

async function importGLB(file){
  if(!file)return;if(!/\.glb$/i.test(file.name)){toast('Choose a binary .glb file');return;}
  const buffer=await file.arrayBuffer();if(new TextDecoder().decode(new Uint8Array(buffer,0,4))!=='glTF'){toast('This file is not a valid binary GLB');return;}
  project.clips=[];project.states=[];project.transitions=[];
  await loadGLBBuffer(buffer,file.name);if(!project.clips.length){toast('Rig imported. Generate a chaotic clip or keyframe it manually.');}else{const first=project.clips[0];selectClip(first.id);}
  scheduleAutosave();
}

// Bundled with GTag Unity: the sample rigs come from GTag Unity's own assets folder
// (.glb in the download, .gltf.json in the Long Fall Arcade copy)
async function fetchSample(p){
  if(p==='original')return originalMonkeGLB();
  // GTag Unity tells us which kind of model files it has (.glb in the download, .gltf.json in the arcade)
  const pref=new URLSearchParams(location.search).get('ext');const order=pref==='.gltf.json'?['.gltf.json','.glb']:['.glb','.gltf.json'];
  for(const ext of order){try{const r=await fetch('../assets/'+p+ext);if(!r.ok)continue;const b=await r.arrayBuffer();const head=new TextDecoder().decode(new Uint8Array(b,0,Math.min(4,b.byteLength)));
    if(head==='glTF'||head.trim().startsWith('{'))return b;}catch(e){}}// (a web page instead of a model is skipped)
  throw new Error('Could not load the bundled '+p.split('/').pop()+' model.');}
// the Original Monke is built from code and turned into a GLB here, so it never needs a model file
async function originalMonkeGLB(){const M=await import('../assets/original_monke.js');const root=M.buildOriginalMonke(THREE,mergeGeometries);const sc=new THREE.Scene();sc.add(root);sc.updateMatrixWorld(true);
  return await exporter.parseAsync(sc,{binary:true,onlyVisible:true});}
// "Send to GTag Unity": the animated rig goes into a small shared database GTag Unity reads
function sharedDB(){return new Promise((res,rej)=>{const q=indexedDB.open('gtag-shared-anims',1);q.onupgradeneeded=()=>q.result.createObjectStore('anims',{keyPath:'name'});q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error);});}
async function sendToGtagUnity(){
  if(!modelRoot){toast('Load a rig first');return;}const previewTime=playhead;
  try{pausePlayback();toast('Sending to GTag Unity…');restoreAllRest();
   const outScene=new THREE.Scene();const cloned=skeletonClone(modelRoot);outScene.add(cloned);outScene.updateMatrixWorld(true);
   const anims=(project.clips||[]).map(makeThreeClip).filter(c=>c.tracks.length);if(!anims.length){toast('Make at least one animation clip first');return;}
   const data=await exporter.parseAsync(outScene,{binary:true,animations:anims,onlyVisible:true,maxTextureSize:2048});
   const name=(project.name||'Monster').slice(0,40);const db=await sharedDB();
   await new Promise((res,rej)=>{const tx=db.transaction('anims','readwrite');tx.objectStore('anims').put({name,data,clips:anims.map(c=>c.name),date:Date.now()});tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});
   toast(`Sent "${name}" (${anims.length} clips) — in GTag Unity pick it under MY ANIMATION on a monster`);
   try{parent.postMessage({gtagAnimSent:name},'*');}catch(e){}
  }catch(e){console.error(e);toast('Sending failed: '+(e.message||e));}
  finally{if(activeClip())applyClipAt(previewTime);}}
async function exportGLB(){
  if(!modelRoot){toast('Import a rigged .glb before exporting');return;}
  const previewTime=playhead;
  try{
    pausePlayback();toast('Preparing animated GLB…');
    restoreAllRest();
    const outScene=new THREE.Scene();const cloned=skeletonClone(modelRoot);outScene.add(cloned);outScene.updateMatrixWorld(true);
    const anims=(project.clips||[]).map(makeThreeClip).filter(c=>c.tracks.length);
    const result=await exporter.parseAsync(outScene,{binary:true,animations:anims,onlyVisible:true,maxTextureSize:4096});
    const blob=new Blob([result],{type:'model/gltf-binary'});downloadBlob(blob,(project.name||'Monster')+'_Animated.glb');toast(`Exported animated GLB · ${anims.length} clips`);
  }catch(e){console.error(e);toast('GLB export failed: '+(e.message||e));}
  finally{if(activeClip())applyClipAt(previewTime);}
}
function downloadBlob(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);}
function arrayBufferToBase64(buf){const bytes=new Uint8Array(buf);let bin='';const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)bin+=String.fromCharCode(...bytes.subarray(i,Math.min(i+chunk,bytes.length)));return btoa(bin);}
function base64ToArrayBuffer(s){const bin=atob(s),bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);return bytes.buffer;}
function serializeProject(){return {...project,modelBuffer:undefined,modelBase64:modelSourceBuffer?arrayBufferToBase64(modelSourceBuffer):project.modelBase64||null,clips:JSON.parse(JSON.stringify(project.clips||[])),states:JSON.parse(JSON.stringify(project.states||[])),transitions:JSON.parse(JSON.stringify(project.transitions||[]))};}
async function saveCurrentProject(showMessage=true){if(!project)return;project.updatedAt=new Date().toISOString();project.modelBuffer=modelSourceBuffer;try{await dbPut(project);setSaveStatus('Saved');if(showMessage)toast('Project saved in this browser');}catch(e){console.error(e);toast('Browser save failed; use Export project as a backup.');}}
function scheduleAutosave(){if(!project)return;setSaveStatus('Unsaved changes');clearTimeout(saveTimer);saveTimer=setTimeout(()=>saveCurrentProject(false),800);}
function exportProject(){if(!project)return;const payload=serializeProject();const blob=new Blob([JSON.stringify(payload)],{type:'application/json'});downloadBlob(blob,(project.name||'GTAG_Animator_Project').replace(/[^\w-]+/g,'_')+'.json');toast('Project file exported with rig and animation data');}
async function openProjectFile(file){try{const data=JSON.parse(await file.text());if(!data||!data.name||!Array.isArray(data.clips))throw new Error('This does not look like a GTAG Animator project file.');if(data.modelBase64)data.modelBuffer=base64ToArrayBuffer(data.modelBase64);await openProject(data);await saveCurrentProject(false);}catch(e){toast('Could not open project: '+e.message);}}

function refreshAll(){updateProjectTitle();renderHierarchy();renderClipList();renderInspector();renderGraph();renderTimeline();}

// UI bindings
$('newProjectBtn').onclick=()=>{window.newTemplate='monster';openModal(`<h2>New animation project</h2><p>Choose a project name and a starting rig.</p><label class="fieldLabel">PROJECT NAME</label><input id="newProjectName" value="Monster Lab" style="width:100%"><div class="modalGrid"><button class="preset selected" data-newtemplate="monster"><b>Monster Lab</b><small>Preloaded Timmy model and chaotic animation examples.</small></button><button class="preset" data-newtemplate="empty"><b>Empty project</b><small>Blank workspace for an imported rig.</small></button><button class="preset" data-newtemplate="gtag"><b>Gorilla Rig Lab</b><small>Gorilla Tag-style rig and starter clips.</small></button></div><div class="modalActions"><button id="newProjectCancel">Cancel</button><button id="newProjectCreate" class="primary">Create project</button></div>`);};
$('modalContent').addEventListener('click',e=>{const b=e.target.closest('[data-newtemplate]');if(!b)return;document.querySelectorAll('[data-newtemplate]').forEach(x=>x.classList.toggle('selected',x===b));window.newTemplate=b.dataset.newtemplate;});
$('modalContent').addEventListener('click',e=>{if(e.target.id==='newProjectCancel')closeModal();if(e.target.id==='newProjectCreate'){const name=$('newProjectName').value.trim()||'Untitled Project';const t=window.newTemplate||'monster';closeModal();createProject(t,name).catch(err=>toast(err.message));}});
$('openProjectBtn').onclick=()=>$('projectFileInput').click();
$('projectFileInput').onchange=e=>{const f=e.target.files[0];if(f)openProjectFile(f);e.target.value='';};
document.querySelectorAll('[data-template]').forEach(b=>b.addEventListener('click',()=>createProject(b.dataset.template).catch(e=>toast(e.message))));
$('backLauncher').onclick=async()=>{await saveCurrentProject(false);showLauncher();};
$('saveBtn').onclick=()=>saveCurrentProject();$('exportProjectBtn').onclick=exportProject;
$('importBtn').onclick=()=>$('glbInput').click();$('glbInput').onchange=e=>{const f=e.target.files[0];if(f)importGLB(f).catch(err=>toast(err.message));e.target.value='';};
$('exportBtn').onclick=exportGLB;$('sendGuBtn').onclick=sendToGtagUnity;$('loadSampleBtn').onclick=loadSample;$('newClipBtn').onclick=createBlankClip;
$('addStateBtn').onclick=addStateFromActive;$('connectBtn').onclick=toggleConnect;$('graphResetBtn').onclick=autoLayoutGraph;$('graphZoomBtn').onclick=()=>{const first=project.states[0];if(first){const area=$('graphArea');const s=project.states;const minX=Math.min(...s.map(x=>x.x)),minY=Math.min(...s.map(x=>x.y));s.forEach(x=>{x.x=x.x-minX+28;x.y=x.y-minY+28;});renderGraph();}};
$('moveModeBtn').onclick=()=>setGizmoMode('translate');$('rotateModeBtn').onclick=()=>setGizmoMode('rotate');$('focusBtn').onclick=focusSelected;$('resetPoseBtn').onclick=resetPose;
$('keyBtn').onclick=insertKeyframe;$('deleteKeyBtn').onclick=deleteKeyframe;$('playBtn').onclick=togglePlayback;$('stopBtn').onclick=stopPlayback;
$('durationInput').onchange=activeClipDurationChange;$('fpsInput').onchange=activeClipDurationChange;$('loopInput').onchange=activeClipDurationChange;
$('helpBtn').onclick=()=>openModal(`<h2>Quick guide</h2><p><b>Import GLB</b> loads a rigged model. Use the Hierarchy to select bones or the rig root. The viewport gizmo and Inspector edit the selected transform.</p><p><b>Keyframes:</b> select a clip, move the playhead, pose a bone and press ◆ Key (or I). Add more poses at different times. Diamonds appear on the timeline.</p><p><b>Chaos generator:</b> create a whole-body monster animation with freeze/stutter, unpredictability and intensity controls. It creates editable keyframes on the rig.</p><p><b>Animator:</b> add states from clips, drag them around and use Connect states to link two nodes.</p><p><b>Export GLB:</b> exports the rig with all animation clips embedded as standard glTF animations. Export project makes a restorable editor project backup.</p><div class="modalActions"><button id="closeHelp" class="primary">Got it</button></div>`);$('modalContent').addEventListener('click',e=>{if(e.target.id==='closeHelp')closeModal();});
$('modalShade').addEventListener('click',e=>{if(e.target.id==='modalShade')closeModal();});
window.addEventListener('keydown',e=>{
  if(e.target.matches('input,textarea,select'))return;
  if(e.code==='Space'){e.preventDefault();togglePlayback();}
  if(e.key.toLowerCase()==='i'){e.preventDefault();insertKeyframe();}
  if(e.key==='Escape'){closeModal();pausePlayback();}
  if(e.key.toLowerCase()==='g'&&e.shiftKey){openChaosModal();}
});
$('viewport').addEventListener('dragover',e=>{e.preventDefault();$('viewport').style.outline='2px dashed #5fc7a1';});
$('viewport').addEventListener('dragleave',()=>{$('viewport').style.outline='none';});
$('viewport').addEventListener('drop',e=>{e.preventDefault();$('viewport').style.outline='none';const f=[...e.dataTransfer.files].find(x=>/\.glb$/i.test(x.name));if(f)importGLB(f).catch(err=>toast(err.message));});

// Modeler-to-Animator handoff: receive a complete GLB containing mesh geometry,
// skin weights and an armature, then open it as a fresh animation project.
window.addEventListener('message',async e=>{
  if(e.origin!==location.origin||e.data?.type!=='gtag-load-modeler-glb'||!e.data.buffer)return;
  try{
    pausePlayback();
    const modelName=String(e.data.name||'GTAG Model').slice(0,64);
    project=emptyProject(modelName);
    showEditor();
    await loadGLBBuffer(e.data.buffer,modelName+'.glb');
    const clip={id:uid(),name:'New Animation',duration:5,fps:24,loop:true,source:'keyframed',tracks:{}};
    project.clips.push(clip);addGraphStateFor(clip);selectClip(clip.id);refreshAll();scheduleAutosave();
    toast(`Modeler transfer complete · ${bones.length} bones · ready to animate`);
    parent.postMessage({type:'gtagAnimatorModelImported',name:modelName,bones:bones.length},location.origin);
  }catch(err){console.error(err);toast('Modeler transfer failed: '+(err.message||err));}
});

// Boot with project picker. A first-time user can create the Monster Lab template in one click.
renderProjectCards();
parent.postMessage({type:'gtagAnimatorReady'},location.origin);
