GTAG ANIMATOR — MONSTER ANIMATION STUDIO

A browser-based 3D animation editor inspired by Unity's Animator and the GTAG Unity v0.9.6 reference project.

START
1. Extract the complete GTAG_Animator folder.
2. Double-click START_ANIMATOR.bat.
3. Your browser opens the local editor automatically.
4. Choose the Monster Lab template, Gorilla Rig Lab, or Empty Animation Project.

REQUIREMENTS
- Windows
- Python 3 (any version, even very old ones like 3.1; no pip packages required)

FEATURES
- Import rigged .glb models.
- Included Timmy monster and Gorilla Tag-style sample rigs.
- Edit individual bones and the model root with a 3D transform gizmo or numeric Inspector values.
- Add keyframes on the timeline with I / the Key button.
- Scrub, play, loop, and adjust animation duration and FPS.
- Unity-style Animator state graph with draggable states and connectable transitions.
- Procedural monster animation generator:
  Chase / Feral, Search / Listening, Jumpscare / Lunge, Idle / Uncanny, Crawl / Spider.
- Controls for intensity, unpredictability, freeze/stutter, duration and keyframe rate.
- Starter Monster Lab includes generated example animations plus any animation clips embedded in the Timmy model.
- Export the rig and all animation clips as a standard animated .glb.
- Save projects in the browser, or export/import portable project .json backups.

IMPORTANT NOTES
- Use rigged GLB files with bone/skeleton data for full-body monster animation. Static models can still be moved as a whole, but do not have individual bones.
- Browser saves are kept locally in the browser profile using IndexedDB. Use Export project for a portable backup.
- The exported GLB contains the current model rig and every clip in the project's clip list. State graph transition conditions are editor metadata and are not exported as runtime game logic.
- This is a local browser app; the small Python server is needed because browsers restrict loading local ES modules and model files directly from file:// URLs.
- The included launcher uses only Python's standard library and runs on every Python 3 version (3.1 and up). If it fails it writes the error to animator_log.txt.

CONTROLS
- Left-drag: orbit camera
- Right-drag: pan camera
- Mouse wheel: zoom
- I: add a keyframe for the selected object/bone
- Space: play/pause the active clip
- Shift+G: open the chaotic animation generator

Built with the Three.js modules included in this folder. No external network connection is required.

FIXES IN v0.1.2 (by Claude)
- The launcher closed right away on older Python versions (error on line 4: "pathlib" does not
  exist before Python 3.4). serve.py is rewritten to work on every Python 3.
- Selecting a model or bone showed "e.getComponent is not a function" and the rotation boxes in the
  Inspector didn't work (three.js rotations have no getComponent/setComponent). Fixed.
- The FPS box was blank for clips made at 18 FPS (the generator's default). 15 and 18 added.
