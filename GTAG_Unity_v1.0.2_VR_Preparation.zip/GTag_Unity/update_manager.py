#!/usr/bin/env python3
"""Safe-ish Windows updater for GTAG Unity. Only installs published GTAG_Unity ZIP assets."""
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, time, urllib.request, zipfile
from pathlib import Path

def request_json(url):
    req=urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','User-Agent':'GTAG-Unity-Updater'})
    with urllib.request.urlopen(req,timeout=30) as r: return json.loads(r.read().decode('utf-8'))

def wait_pid(pid):
    if os.name=='nt':
        import ctypes
        SYNCHRONIZE=0x00100000
        h=ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE,False,int(pid))
        if h:
            ctypes.windll.kernel32.WaitForSingleObject(h,30000)
            ctypes.windll.kernel32.CloseHandle(h)
    else:
        for _ in range(100):
            try: os.kill(int(pid),0)
            except OSError: return
            time.sleep(.2)

def safe_extract(zf, dest):
    base=os.path.abspath(dest)
    for info in zf.infolist():
        name=info.filename.replace('\\','/')
        if name.startswith('/') or any(part=='..' for part in name.split('/')):
            raise RuntimeError('Update ZIP contains an unsafe file path.')
        target=os.path.abspath(os.path.join(base,*name.split('/')))
        if not (target==base or target.startswith(base+os.sep)):
            raise RuntimeError('Update ZIP path escapes the install folder.')
        if info.is_dir(): os.makedirs(target,exist_ok=True)
        else:
            os.makedirs(os.path.dirname(target),exist_ok=True)
            with zf.open(info) as src, open(target,'wb') as dst: shutil.copyfileobj(src,dst)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--repo',required=True); ap.add_argument('--pid',required=True); ap.add_argument('--app',action='store_true'); a=ap.parse_args()
    app=Path(__file__).resolve().parent; parent=app.parent; log=parent/'gtag_update.log'
    def write(msg):
        with open(log,'a',encoding='utf-8') as f: f.write(time.strftime('%Y-%m-%d %H:%M:%S ')+msg+'\n')
    backup=None
    try:
        write('Waiting for app process to close.')
        wait_pid(a.pid)
        release=request_json('https://api.github.com/repos/'+a.repo+'/releases/latest')
        asset=next((x for x in release.get('assets',[]) if x.get('name','').lower().endswith('.zip') and 'gtag_unity' in x.get('name','').lower()),None)
        if not asset: raise RuntimeError('No GTAG_Unity ZIP asset found in latest release.')
        digest=asset.get('digest')
        if not digest or not digest.startswith('sha256:'): raise RuntimeError('GitHub did not provide a SHA-256 asset digest; refusing an unverified update.')
        tmp=Path(tempfile.mkdtemp(prefix='gtag_update_'))
        archive=tmp/'update.zip'
        req=urllib.request.Request(asset['browser_download_url'],headers={'User-Agent':'GTAG-Unity-Updater'})
        with urllib.request.urlopen(req,timeout=120) as r, open(archive,'wb') as f: shutil.copyfileobj(r,f)
        h=hashlib.sha256(archive.read_bytes()).hexdigest()
        if h.lower()!=digest.split(':',1)[1].lower(): raise RuntimeError('Update archive SHA-256 verification failed.')
        extracted=tmp/'extract'; extracted.mkdir()
        with zipfile.ZipFile(archive) as z: safe_extract(z,extracted)
        candidates=list(extracted.rglob('serve.py'))
        if len(candidates)!=1: raise RuntimeError('Update archive must contain exactly one GTAG Unity app folder.')
        newroot=candidates[0].parent
        if not (newroot/'index.html').is_file() or not (newroot/'START_BUILDER.bat').is_file(): raise RuntimeError('Update archive is missing required app files.')
        stamp=time.strftime('%Y%m%d_%H%M%S'); backup=parent/(app.name+'_backup_'+stamp)
        shutil.copytree(str(app),str(backup))
        preserve=('quest_cert.pem','quest_key.pem','update_config.json','builder_log.txt')
        for src in newroot.rglob('*'):
            rel=src.relative_to(newroot)
            if any(part in preserve for part in rel.parts): continue
            dst=app/rel
            if src.is_dir(): dst.mkdir(parents=True,exist_ok=True)
            else:
                dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(str(src),str(dst))
        write('Installed '+str(release.get('tag_name'))+'; backup='+str(backup))
        subprocess.Popen([sys.executable,str(app/'serve.py'),'--no-browser'],cwd=str(app),close_fds=(os.name!='nt'))
    except Exception as e:
        if backup is not None and backup.exists():
            try:
                failed=parent/(app.name+'_failed_'+time.strftime('%Y%m%d_%H%M%S'))
                if app.exists(): shutil.move(str(app),str(failed))
                shutil.copytree(str(backup),str(app))
                write('Restored previous app from backup '+str(backup))
            except Exception as rollback_error:
                write('ROLLBACK FAILED: '+repr(rollback_error))
        write('UPDATE FAILED: '+repr(e))
        try: subprocess.Popen(['cmd','/c','start','',str(app/'START_BUILDER.bat')],cwd=str(app))
        except Exception: pass
        sys.exit(1)

if __name__=='__main__': main()
