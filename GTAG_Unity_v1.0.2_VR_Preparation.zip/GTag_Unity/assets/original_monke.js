// ORIGINAL MONKE — a gorilla made only from code (no model files needed).
// Low-poly like Gorilla Tag, with a real skeleton so it can be posed, animated and used as a monster.
// Bone names match the GTag rig (torso, head, shoulder.L, upper_arm.L, forearm.L, hand.L …) so every
// animation in GTag Unity and the Monster Animator works on it.
export function buildOriginalMonke(THREE, mergeGeometries, {fur = '#7a6f66'} = {}) {
  const V = THREE.Vector3;
  const root = new THREE.Group(); root.name = 'Original Monke';
  // ---------- skeleton (rest pose: standing, knuckles on the floor) ----------
  const bones = [], byName = {};
  const bone = (name, parent, world) => {
    const b = new THREE.Bone(); b.name = name; b.userData.world = world.clone();
    if (parent) { b.position.copy(world.clone().sub(parent.userData.world)); parent.add(b); } else b.position.copy(world);
    bones.push(b); byName[name] = b; return b;
  };
  const rootB = bone('root', null, new V(0, 0, 0));
  const torso = bone('torso', rootB, new V(0, .62, 0));
  const head = bone('head', torso, new V(0, 1.3, .02));
  const J = {};
  for (const [s, x] of [['L', 1], ['R', -1]]) {
    const sh = bone('shoulder.' + s, torso, new V(.2 * x, 1.17, 0));
    const up = bone('upper_arm.' + s, sh, new V(.36 * x, 1.15, .02));
    const fo = bone('forearm.' + s, up, new V(.47 * x, .74, .08));
    const ha = bone('hand.' + s, fo, new V(.51 * x, .33, .12));
    bone('hand_end.' + s, ha, new V(.53 * x, .16, .17));
    J[s] = { up, fo, ha };
  }
  // ---------- body parts (each part follows one bone) ----------
  const parts = [];
  const skin = (g, b, mat) => {
    g = g.toNonIndexed(); const n = g.attributes.position.count; const bi = bones.indexOf(b);
    const si = new Uint16Array(n * 4), sw = new Float32Array(n * 4); for (let i = 0; i < n; i++) { si[i * 4] = bi; sw[i * 4] = 1; }
    g.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(si, 4)); g.setAttribute('skinWeight', new THREE.Float32BufferAttribute(sw, 4));
    if (!g.attributes.uv) g.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(n * 2), 2));
    parts.push({ g, mat });
  };
  const blob = (b, c, s, mat = 0, seg = [12, 9]) => { const g = new THREE.SphereGeometry(1, seg[0], seg[1]); g.scale(s[0], s[1], s[2]); g.translate(c[0], c[1], c[2]); skin(g, b, mat); return g; };
  const limb = (b, a, z, r0, r1) => { const d = z.clone().sub(a); const L = d.length(); const g = new THREE.CylinderGeometry(r1, r0, L, 9, 1); g.translate(0, L / 2, 0);
    g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new V(0, 1, 0), d.normalize())); g.translate(a.x, a.y, a.z); skin(g, b, 0); };
  blob(torso, [0, .86, -.01], [.37, .47, .31]);                       // body
  blob(torso, [0, .88, .2], [.25, .31, .13], 1);                      // chest
  blob(head, [0, 1.5, .0], [.27, .24, .25]);                          // head
  blob(head, [0, 1.6, -.03], [.21, .1, .2]);                          // brow / top
  for (const x of [1, -1]) blob(head, [.25 * x, 1.52, -.02], [.06, .07, .04]); // ears
  // face: a flat disc with its own picture (planar UVs, same layout as GTag faces)
  const face = new THREE.SphereGeometry(1, 16, 10); face.scale(.2, .17, .09); face.translate(0, 1.49, .19);
  { const p = face.attributes.position, uv = face.attributes.uv; for (let i = 0; i < p.count; i++) uv.setXY(i, (p.getX(i) + .2) / .4, 1 - (p.getY(i) - 1.32) / .34); }
  skin(face, head, 2);
  for (const s of ['L', 'R']) { const j = J[s];
    blob(j.up, j.up.userData.world.toArray(), [.14, .14, .13]);       // shoulder ball
    limb(j.up, j.up.userData.world, j.fo.userData.world, .12, .1);
    blob(j.fo, j.fo.userData.world.toArray(), [.1, .1, .1]);          // elbow
    limb(j.fo, j.fo.userData.world, j.ha.userData.world, .1, .085);
    const h = j.ha.userData.world; blob(j.ha, [h.x * 1.02, h.y - .07, h.z + .04], [.1, .08, .12]); // hand
  }
  const geo = mergeGeometries(parts.map(p => p.g), true); parts.forEach((p, i) => geo.groups[i].materialIndex = p.mat); geo.computeVertexNormals();
  // ---------- materials (fur colour can be changed like the GTag gorilla's) ----------
  const furTex = canvasTex(128, 128, (x, w, h) => { x.fillStyle = '#c9c9c9'; x.fillRect(0, 0, w, h); for (let i = 0; i < 1400; i++) { const v = 150 + Math.random() * 105 | 0; x.fillStyle = `rgb(${v},${v},${v})`; x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 3 + Math.random() * 6); } }, THREE);
  furTex.wrapS = furTex.wrapT = THREE.RepeatWrapping; furTex.repeat.set(3, 3);
  const chestTex = canvasTex(64, 64, (x, w, h) => { x.fillStyle = '#9a9a9a'; x.fillRect(0, 0, w, h); for (let i = 0; i < 400; i++) { const v = 110 + Math.random() * 90 | 0; x.fillStyle = `rgb(${v},${v},${v})`; x.fillRect(Math.random() * w, Math.random() * h, 2, 2); } }, THREE);
  const faceTex = canvasTex(256, 256, drawFace, THREE); faceTex.flipY = false;
  const mats = [
    new THREE.MeshStandardMaterial({ name: 'GorillaTagColor', color: fur, map: furTex, roughness: .9, flatShading: true }),
    new THREE.MeshStandardMaterial({ name: 'Chest', map: chestTex, roughness: .9, flatShading: true }),
    new THREE.MeshStandardMaterial({ name: 'Face', map: faceTex, roughness: .8 })];
  const mesh = new THREE.SkinnedMesh(geo, mats); mesh.name = 'Original Monke body'; mesh.castShadow = true; mesh.frustumCulled = false;
  root.add(rootB); root.add(mesh); root.updateMatrixWorld(true);
  mesh.bind(new THREE.Skeleton(bones));
  return root;
}
function canvasTex(w, h, draw, THREE) { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); draw(x, w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; }
// same layout as GTag face pictures: forehead at the top, eyes in the middle, mouth at the bottom.
// A gorilla face, not a human one: heart-shaped face plate, deep dark eyes, big nostrils, flat mouth.
function drawFace(x, w, h) {
  x.fillStyle = '#3a3532'; x.fillRect(0, 0, w, h);                       // dark skin around the plate
  const plate = () => { x.beginPath(); x.ellipse(w * .33, h * .38, w * .2, h * .2, 0, 0, 6.283); x.ellipse(w * .67, h * .38, w * .2, h * .2, 0, 0, 6.283); x.ellipse(w * .5, h * .66, w * .3, h * .28, 0, 0, 6.283); };
  x.fillStyle = '#8d8580'; plate(); x.fill();
  x.fillStyle = '#6d6661'; x.beginPath(); x.ellipse(w * .5, h * .2, w * .34, h * .07, 0, 0, 6.283); x.fill();   // heavy brow
  for (const ex of [.34, .66]) { x.fillStyle = '#141110'; x.beginPath(); x.ellipse(w * ex, h * .4, w * .085, h * .075, 0, 0, 6.283); x.fill();
    x.fillStyle = '#5a1e14'; x.beginPath(); x.arc(w * ex, h * .405, w * .035, 0, 6.283); x.fill(); x.fillStyle = '#e8e2da'; x.beginPath(); x.arc(w * (ex - .02), h * .385, w * .012, 0, 6.283); x.fill(); }
  x.fillStyle = '#5e5752'; x.beginPath(); x.ellipse(w * .5, h * .6, w * .16, h * .1, 0, 0, 6.283); x.fill();      // nose pad
  x.fillStyle = '#121010'; for (const nx of [.43, .57]) { x.beginPath(); x.ellipse(w * nx, h * .61, w * .045, h * .035, nx < .5 ? .5 : -.5, 0, 6.283); x.fill(); }
  x.strokeStyle = '#1c1816'; x.lineWidth = 7; x.beginPath(); x.moveTo(w * .36, h * .8); x.quadraticCurveTo(w * .5, h * .77, w * .64, h * .8); x.stroke();   // flat mouth
}
