# GTAG Unity multiplayer room server.
# Standard-library only: compatible with the Python version used by the local builder.
from __future__ import print_function
import os
import sys
import json
import time
import uuid
import base64
import hashlib
import struct
import socket
import threading
import http.server
import socketserver

HOST = '0.0.0.0'
PORT = int(os.environ.get('PORT', '8787'))
MAX_CLIENTS = 8
UID_NAMESPACE_MAX = 1 << 29
UID_SLOT_LIMIT = 256
MAX_MESSAGE = 32 * 1024 * 1024
ROOM_TTL = 24 * 60 * 60
GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
DATA_DIR = os.environ.get('DATA_DIR', '').strip()
ROOM_FILE = os.path.join(DATA_DIR, 'rooms.json') if DATA_DIR else ''

ROOMS = {}
ROOM_LOCK = threading.RLock()
JOIN_ATTEMPTS = {}
PERSIST_LOCK = threading.Lock()
PERSIST_PENDING = [False]


def clean_text(value, max_len, fallback=''):
    try:
        s = str(value if value is not None else '')
    except Exception:
        s = ''
    s = ''.join(ch for ch in s if ord(ch) >= 32 and ord(ch) != 127).strip()
    return s[:max_len] or fallback


def clean_code(value):
    s = ''.join(ch for ch in str(value or '').upper() if ch.isalnum())[:8]
    return s if len(s) >= 4 else ''


def random_code():
    import random
    while True:
        code = ''.join(random.choice(ALPHABET) for _ in range(6))
        with ROOM_LOCK:
            if code not in ROOMS:
                return code


def random_uid_namespace():
    used = set(room.get('uidNamespace') for room in ROOMS.values())
    while True:
        value = (uuid.uuid4().int % (UID_NAMESPACE_MAX - 1024)) + 1024
        if value not in used:
            return value


def clean_color(value):
    s = str(value or '').strip()
    if len(s) == 7 and s.startswith('#'):
        try:
            int(s[1:], 16)
            return s.lower()
        except Exception:
            pass
    return '#ffffff'


def clean_pose(value):
    if not isinstance(value, dict):
        return None
    p = value.get('p')
    if not isinstance(p, (list, tuple)) or len(p) != 3:
        return None
    try:
        p = [float(p[0]), float(p[1]), float(p[2])]
        yaw = float(value.get('yaw', 0))
        speed = float(value.get('speed', 0))
    except Exception:
        return None
    if any(abs(x) > 100000 for x in p):
        return None
    return {'p': [round(x, 3) for x in p], 'yaw': max(-1000, min(1000, yaw)),
            'speed': max(0, min(100, speed)), 'grounded': value.get('grounded') is not False,
            'playing': value.get('playing') is True}


def clean_cursor(value):
    if value is None:
        return None
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return None
    try:
        point = [float(value[0]), float(value[1]), float(value[2])]
    except Exception:
        return None
    if any(abs(x) > 100000 for x in point):
        return None
    return [round(x, 2) for x in point]


def json_bytes(value):
    return json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def send_frame(handler, opcode, payload):
    if isinstance(payload, str):
        payload = payload.encode('utf-8')
    length = len(payload)
    first = bytes(bytearray([0x80 | opcode]))
    if length < 126:
        header = first + bytes(bytearray([length]))
    elif length <= 65535:
        header = first + bytes(bytearray([126])) + struct.pack('!H', length)
    else:
        header = first + bytes(bytearray([127])) + struct.pack('!Q', length)
    with handler.send_lock:
        if handler.ws_closed:
            return
        try:
            handler.connection.sendall(header + payload)
        except Exception:
            handler.ws_closed = True


def ws_send(handler, value):
    try:
        data = json_bytes(value)
        if len(data) > MAX_MESSAGE:
            return
        send_frame(handler, 1, data)
    except Exception:
        pass


def public_player(client):
    return {'id': client['id'], 'joinIndex': client['joinIndex'], 'name': client['name'],
            'color': client['color'], 'pose': client.get('pose'), 'cursor': client.get('cursor')}


def room_players(room):
    return sorted([public_player(c) for c in room['clients'].values()], key=lambda p: p['joinIndex'])


def broadcast(room, value, except_id=None):
    with ROOM_LOCK:
        clients = list(room['clients'].values())
    for c in clients:
        if c['id'] != except_id:
            ws_send(c['handler'], value)


def schedule_persist():
    if not DATA_DIR:
        return
    with PERSIST_LOCK:
        if PERSIST_PENDING[0]:
            return
        PERSIST_PENDING[0] = True
    def write_later():
        time.sleep(.7)
        try:
            if not os.path.isdir(DATA_DIR):
                os.makedirs(DATA_DIR)
            rows = []
            with ROOM_LOCK:
                for room in ROOMS.values():
                    rows.append({'code': room['code'], 'nextJoin': room['nextJoin'],
                                 'nextUidSlot': room.get('nextUidSlot', room['nextJoin']),
                                 'uidNamespace': room.get('uidNamespace'),
                                 'revision': room['revision'], 'updatedAt': room['updatedAt'],
                                 'snapshot': room.get('snapshot')})
            tmp = ROOM_FILE + '.tmp'
            f = open(tmp, 'wb')
            try:
                f.write(json_bytes(rows))
            finally:
                f.close()
            if os.path.exists(ROOM_FILE):
                os.remove(ROOM_FILE)
            os.rename(tmp, ROOM_FILE)
        except Exception as e:
            print('Room persistence failed: ' + str(e))
        finally:
            with PERSIST_LOCK:
                PERSIST_PENDING[0] = False
    t = threading.Thread(target=write_later)
    t.daemon = True
    t.start()


def load_persisted():
    if not ROOM_FILE or not os.path.isfile(ROOM_FILE):
        return
    try:
        f = open(ROOM_FILE, 'rb')
        try:
            rows = json.loads(f.read().decode('utf-8'))
        finally:
            f.close()
        if not isinstance(rows, list):
            return
        for row in rows:
            code = clean_code(row.get('code'))
            snap = row.get('snapshot')
            if code and isinstance(snap, dict) and isinstance(snap.get('project'), dict):
                namespace = row.get('uidNamespace')
                try:
                    namespace = int(namespace)
                    if namespace < 1024 or namespace >= UID_NAMESPACE_MAX:
                        namespace = None
                except Exception:
                    namespace = None
                if namespace is None:
                    namespace = random_uid_namespace()
                ROOMS[code] = {'code': code, 'hostId': None, 'clients': {},
                               'nextJoin': int(row.get('nextJoin', 0)),
                               'nextUidSlot': int(row.get('nextUidSlot', row.get('nextJoin', 0))),
                               'uidNamespace': namespace, 'revision': int(row.get('revision', 0)),
                               'updatedAt': float(row.get('updatedAt', time.time())),
                               'emptyAt': time.time(), 'snapshot': snap}
        print('Restored ' + str(len(ROOMS)) + ' saved room(s).')
    except Exception as e:
        print('Could not restore room saves: ' + str(e))


def merge_patch(snapshot, patch):
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get('project'), dict) or not isinstance(patch, dict):
        raise ValueError('invalid room project')
    project = snapshot['project']
    objects = {}
    for obj in project.get('objects', []) if isinstance(project.get('objects'), list) else []:
        if isinstance(obj, dict) and obj.get('uid') is not None:
            objects[str(obj.get('uid'))] = obj
    for uid in patch.get('deletedUids', []) if isinstance(patch.get('deletedUids'), list) else []:
        objects.pop(str(uid), None)
    for obj in patch.get('upsertObjects', []) if isinstance(patch.get('upsertObjects'), list) else []:
        if isinstance(obj, dict) and obj.get('uid') is not None and isinstance(obj.get('type'), str):
            objects[str(obj.get('uid'))] = obj
    if len(objects) > 12000:
        raise ValueError('too many scene objects')
    project['objects'] = list(objects.values())

    edits = project.get('mapEdits') if isinstance(project.get('mapEdits'), dict) else {}
    for key in patch.get('deletedMapEditIds', []) if isinstance(patch.get('deletedMapEditIds'), list) else []:
        edits.pop(str(key), None)
    if isinstance(patch.get('mapEdits'), dict):
        for key, edit in patch['mapEdits'].items():
            if len(str(key)) <= 256 and isinstance(edit, dict):
                edits[str(key)] = edit
    project['mapEdits'] = edits

    allowed = ('map', 'env', 'player', 'scripts', 'vars', 'spawn', 'lobby', 'wearing',
               'animLen', 'ambience', 'shop', 'factory', 'customMonsters')
    fields = patch.get('fields')
    if isinstance(fields, dict):
        for key in allowed:
            if key in fields:
                project[key] = fields[key]

    blobs = snapshot.get('blobs') if isinstance(snapshot.get('blobs'), dict) else {}
    new_blobs = patch.get('blobs')
    if isinstance(new_blobs, dict):
        for key, blob in new_blobs.items():
            if len(str(key)) > 160 or not isinstance(blob, dict) or not isinstance(blob.get('b64'), str):
                continue
            if len(blob['b64']) > 24 * 1024 * 1024:
                raise ValueError('one imported asset is too large to sync')
            blobs[str(key)] = blob
    snapshot['blobs'] = blobs


def remove_client(client):
    if client.get('removed'):
        return
    client['removed'] = True
    code = client.get('roomCode')
    with ROOM_LOCK:
        room = ROOMS.get(code)
        if not room:
            return
        room['clients'].pop(client['id'], None)
        room['updatedAt'] = time.time()
        if not room['clients']:
            room['emptyAt'] = time.time()
        left = {'type': 'peer_left', 'id': client['id'], 'name': client['name']}
        new_host = None
        if room.get('hostId') == client['id']:
            promoted = sorted(room['clients'].values(), key=lambda item: item['joinIndex'])
            room['hostId'] = promoted[0]['id'] if promoted else None
            if promoted:
                new_host = {'type': 'host_changed', 'id': promoted[0]['id'], 'name': promoted[0]['name']}
    broadcast(room, left)
    if new_host:
        broadcast(room, new_host)
    schedule_persist()


def rate_limited(ip):
    now = time.time()
    rec = JOIN_ATTEMPTS.get(ip, [now, 0])
    if now - rec[0] > 60:
        rec = [now, 0]
    rec[1] += 1
    JOIN_ATTEMPTS[ip] = rec
    return rec[1] > 15


class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        if self.path == '/' or self.path.startswith('/health'):
            body = json_bytes({'ok': True, 'service': 'GTAG Unity Multiplayer', 'rooms': len(ROOMS),
                               'websocket': '/ws', 'maxPlayersPerRoom': MAX_CLIENTS})
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path == '/ws':
            self.handle_websocket()
            return
        self.send_error(404, 'Not found')

    def read_exact(self, n):
        out = []
        left = n
        while left > 0:
            part = self.rfile.read(left)
            if not part:
                raise IOError('socket closed')
            out.append(part)
            left -= len(part)
        return b''.join(out)

    def send_ws_frame(self, opcode, payload):
        send_frame(self, opcode, payload)

    def handle_websocket(self):
        key = self.headers.get('Sec-WebSocket-Key')
        upgrade = (self.headers.get('Upgrade') or '').lower()
        if not key or upgrade != 'websocket':
            self.send_error(400, 'WebSocket upgrade required')
            return
        accept = base64.b64encode(hashlib.sha1((key + GUID).encode('ascii')).digest()).decode('ascii')
        self.send_response(101, 'Switching Protocols')
        self.send_header('Upgrade', 'websocket')
        self.send_header('Connection', 'Upgrade')
        self.send_header('Sec-WebSocket-Accept', accept)
        self.end_headers()
        try:
            self.wfile.flush()
        except Exception:
            return
        self.close_connection = True
        self.send_lock = threading.Lock()
        self.ws_closed = False
        self.client = None
        try:
            self.connection.settimeout(45)
            fragments = []
            fragment_opcode = None
            while not self.ws_closed:
                try:
                    head = self.read_exact(2)
                except Exception:
                    break
                b1 = head[0] if not isinstance(head[0], str) else ord(head[0])
                b2 = head[1] if not isinstance(head[1], str) else ord(head[1])
                fin = bool(b1 & 0x80)
                opcode = b1 & 0x0f
                masked = bool(b2 & 0x80)
                length = b2 & 0x7f
                if length == 126:
                    length = struct.unpack('!H', self.read_exact(2))[0]
                elif length == 127:
                    length = struct.unpack('!Q', self.read_exact(8))[0]
                if length > MAX_MESSAGE:
                    self.send_ws_frame(8, struct.pack('!H', 1009))
                    break
                mask = self.read_exact(4) if masked else None
                payload = self.read_exact(length) if length else b''
                if mask:
                    payload = bytes(bytearray([payload[i] ^ mask[i % 4] for i in range(len(payload))]))
                if opcode == 8:
                    try:
                        self.send_ws_frame(8, payload[:125])
                    except Exception:
                        pass
                    break
                if opcode == 9:
                    self.send_ws_frame(10, payload)
                    continue
                if opcode == 10:
                    continue
                if opcode in (1, 2):
                    fragment_opcode = opcode
                    fragments = [payload]
                elif opcode == 0 and fragment_opcode is not None:
                    fragments.append(payload)
                else:
                    continue
                if fin and fragment_opcode is not None:
                    data = b''.join(fragments)
                    op = fragment_opcode
                    fragments = []
                    fragment_opcode = None
                    if op == 1:
                        try:
                            msg = json.loads(data.decode('utf-8'))
                            self.handle_message(msg)
                        except Exception as e:
                            ws_send(self, {'type': 'error', 'message': 'Could not process message: ' + str(e)[:180]})
        finally:
            self.ws_closed = True
            if self.client:
                remove_client(self.client)

    def handle_message(self, msg):
        if not isinstance(msg, dict) or not isinstance(msg.get('type'), str):
            return
        kind = msg.get('type')
        if kind == 'join':
            if self.client:
                ws_send(self, {'type': 'error', 'message': 'This connection already joined a room.'})
                return
            ip = self.client_address[0] if self.client_address else 'unknown'
            if rate_limited(ip):
                ws_send(self, {'type': 'error', 'message': 'Too many room attempts. Try again in a minute.'})
                self.ws_closed = True
                return
            create = msg.get('create') is True
            code = clean_code(msg.get('room'))
            if not code and create:
                code = random_code()
            if not code:
                ws_send(self, {'type': 'error', 'message': 'Enter a valid 4–8 character room code.'})
                return
            with ROOM_LOCK:
                room = ROOMS.get(code)
                if create:
                    if room and (room['clients'] or room.get('snapshot')):
                        ws_send(self, {'type': 'error', 'message': 'That room code is already in use. Create another room.'})
                        return
                    room = {'code': code, 'hostId': None, 'clients': {}, 'nextJoin': 0, 'nextUidSlot': 0,
                            'uidNamespace': random_uid_namespace(), 'revision': 0,
                            'updatedAt': time.time(), 'emptyAt': None, 'snapshot': None}
                    ROOMS[code] = room
                elif not room:
                    ws_send(self, {'type': 'error', 'message': 'Room not found. Check the code or ask your friend to create it first.'})
                    return
                if len(room['clients']) >= MAX_CLIENTS:
                    ws_send(self, {'type': 'error', 'message': 'Room is full (maximum 8 players).'})
                    return
                if room.get('nextUidSlot', 0) >= UID_SLOT_LIMIT:
                    ws_send(self, {'type': 'error', 'message': 'This room has reached 256 total join sessions. Create a new room to continue collaborative editing.'})
                    return
                uid_slot = room.get('nextUidSlot', 0)
                room['nextUidSlot'] = uid_slot + 1
                client = {'id': str(uuid.uuid4()), 'handler': self, 'roomCode': code,
                          'joinIndex': room['nextJoin'], 'uidSlot': uid_slot,
                          'name': clean_text(msg.get('name'), 12, 'Guest'),
                          'color': clean_color(msg.get('color')), 'pose': None, 'cursor': None, 'lastPoseAt': 0, 'lastCursorAt': 0, 'removed': False}
                room['nextJoin'] += 1
                room['clients'][client['id']] = client
                room['updatedAt'] = time.time()
                room['emptyAt'] = None
                if not room.get('hostId'):
                    room['hostId'] = client['id']
                self.client = client
                welcome = {'type': 'welcome', 'id': client['id'], 'room': code, 'joinIndex': client['joinIndex'],
                           'uidNamespace': room['uidNamespace'], 'uidSlot': uid_slot,
                           'host': room['hostId'] == client['id'], 'created': create, 'revision': room['revision'],
                           'players': room_players(room), 'snapshot': room.get('snapshot')}
            ws_send(self, welcome)
            broadcast(room, {'type': 'peer_join', 'player': public_player(client)}, client['id'])
            schedule_persist()
            print(client['name'] + ' joined ' + code + ' (' + str(len(room['clients'])) + ' online)')
            return

        client = self.client
        if not client:
            ws_send(self, {'type': 'error', 'message': 'Join a room first.'})
            return
        with ROOM_LOCK:
            room = ROOMS.get(client['roomCode'])
        if not room:
            ws_send(self, {'type': 'error', 'message': 'Room no longer exists.'})
            return

        if kind == 'leave':
            remove_client(client)
            self.ws_closed = True
            return
        if kind == 'ping':
            ws_send(self, {'type': 'pong', 't': msg.get('t', int(time.time() * 1000))})
            return
        if kind == 'profile':
            client['name'] = clean_text(msg.get('name'), 12, client['name'])
            client['color'] = clean_color(msg.get('color'))
            broadcast(room, {'type': 'peer_profile', 'id': client['id'], 'name': client['name'], 'color': client['color']})
            return
        if kind == 'pose':
            now = time.time()
            if now - client['lastPoseAt'] < .035:
                return
            pose = clean_pose(msg.get('pose'))
            if pose is None:
                return
            client['lastPoseAt'] = now
            client['pose'] = pose
            broadcast(room, {'type': 'peer_pose', 'id': client['id'], 'pose': pose}, client['id'])
            return
        if kind == 'cursor':
            now = time.time()
            if now - client['lastCursorAt'] < .09:
                return
            cursor = clean_cursor(msg.get('cursor'))
            client['lastCursorAt'] = now
            client['cursor'] = cursor
            broadcast(room, {'type': 'peer_cursor', 'id': client['id'], 'cursor': cursor}, client['id'])
            return
        if kind == 'scene_seed':
            if client['id'] != room.get('hostId') or room.get('snapshot'):
                ws_send(self, {'type': 'error', 'message': 'Only the room creator can create the first shared scene snapshot.'})
                return
            snap = msg.get('snapshot')
            if not isinstance(snap, dict) or not isinstance(snap.get('project'), dict) or len(json_bytes(snap)) > MAX_MESSAGE - 1024:
                ws_send(self, {'type': 'error', 'message': 'The shared project snapshot is too large or invalid.'})
                return
            room['snapshot'] = snap
            room['revision'] += 1
            room['updatedAt'] = time.time()
            ws_send(self, {'type': 'scene_ack', 'revision': room['revision']})
            broadcast(room, {'type': 'scene_seed', 'snapshot': snap, 'revision': room['revision']}, client['id'])
            schedule_persist()
            return
        if kind == 'scene_patch':
            if not room.get('snapshot'):
                ws_send(self, {'type': 'error', 'message': 'The host has not shared the room project yet.'})
                return
            patch = msg.get('patch')
            if not isinstance(patch, dict) or len(json_bytes(patch)) > MAX_MESSAGE - 1024:
                ws_send(self, {'type': 'error', 'message': 'The edit packet is too large or invalid.'})
                return
            try:
                with ROOM_LOCK:
                    merge_patch(room['snapshot'], patch)
                    room['revision'] += 1
                    revision = room['revision']
                    room['updatedAt'] = time.time()
            except Exception as e:
                ws_send(self, {'type': 'error', 'message': 'Could not apply shared edit: ' + str(e)[:180]})
                return
            ws_send(self, {'type': 'scene_ack', 'revision': revision, 'seq': msg.get('seq', 0)})
            broadcast(room, {'type': 'scene_patch', 'patch': patch, 'revision': revision, 'by': client['id']}, client['id'])
            schedule_persist()
            return
        ws_send(self, {'type': 'error', 'message': 'Unknown message type: ' + kind})

    def end_headers(self):
        http.server.BaseHTTPRequestHandler.end_headers(self)


class QuietHTTPServer(ThreadingHTTPServer):
    def handle_error(self, request, client_address):
        pass


def cleanup_loop():
    while True:
        time.sleep(60)
        now = time.time()
        with ROOM_LOCK:
            dead = [code for code, room in ROOMS.items() if not room['clients'] and room.get('emptyAt') and now - room['emptyAt'] > ROOM_TTL]
            for code in dead:
                del ROOMS[code]
        for ip, record in list(JOIN_ATTEMPTS.items()):
            if now - record[0] > 120:
                JOIN_ATTEMPTS.pop(ip, None)
        if dead:
            schedule_persist()


load_persisted()
cleaner = threading.Thread(target=cleanup_loop)
cleaner.daemon = True
cleaner.start()
httpd = QuietHTTPServer((HOST, PORT), Handler)
print('GTAG Unity multiplayer server listening on 0.0.0.0:' + str(PORT))
print('Health: http://127.0.0.1:' + str(PORT) + '/health')
print('WebSocket: ws://127.0.0.1:' + str(PORT) + '/ws')
print('Keep this server window open while you and your friend are connected.')
try:
    httpd.serve_forever()
except KeyboardInterrupt:
    print('Stopping multiplayer server…')
finally:
    if DATA_DIR:
        schedule_persist()
    httpd.server_close()
