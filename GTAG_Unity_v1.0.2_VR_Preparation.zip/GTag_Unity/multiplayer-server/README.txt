GTAG UNITY — ONLINE MULTIPLAYER SERVER
======================================

This server powers private GTAG Unity rooms. It uses Python's standard library only; no npm install or extra Python package is needed.

LOCAL TEST (same PC)
--------------------
1. Extract the complete GTAG Unity folder.
2. Double-click START_MULTIPLAYER_SERVER.bat in the main GTag_Unity folder.
3. Leave the black server window open.
4. Open GTAG Unity with START_BUILDER.bat.
5. Click the 🌐 Co-op button.
6. Leave the Server Address as ws://127.0.0.1:8787/ws.
7. Click Create room. Share the room code with your friend.
8. Your friend joins from their own PC using the same server address and room code (use your LAN IP if they are on the same Wi-Fi).

SAME WI-FI / LAN
----------------
The host starts START_MULTIPLAYER_SERVER.bat. Find the host PC's local IPv4 address in Windows network settings (usually 192.168.x.x or 10.x.x.x).
Both players enter:
  ws://HOST-LAN-IP:8787/ws
For example:
  ws://192.168.1.25:8787/ws
The host may need to allow Python through Windows Firewall on a private network. The launcher stores room snapshots in multiplayer-server\data so local room projects survive server restarts. Do not expose port 8787 to the public internet without a hosted secure endpoint.

FRIEND IN ANOTHER HOME (PUBLIC SERVER)
--------------------------------------
The local server is not automatically reachable over the internet. Deploy this multiplayer-server folder as a Python Web Service with a provider that supports WebSocket upgrades, then use its secure WebSocket URL in the game.

Example deployment using Render:
  Root Directory: multiplayer-server
  Runtime: Python
  Build Command: pip install -r requirements.txt
  Start Command: python server.py
After deployment, the public service URL will be similar to:
  wss://YOUR-SERVICE.onrender.com/ws
Use that exact wss:// URL in the Co-op panel on both PCs. The service must stay running while you play.

For providers that offer a persistent disk, set DATA_DIR to the disk mount path (for example /var/data). Room snapshots can then be saved between server restarts. Without a persistent disk, room snapshots live in server memory and may be lost when the hosting process restarts or sleeps.

HOW CO-OP WORKS
---------------
- Up to 8 players at once and 256 join sessions per room lifetime; create a new room after that limit.
- The room creator seeds the current project as the shared starting scene.
- Object additions, deletions, transforms, map-part edits, lights, monsters, portals, scripts, environment, ambience and shop settings sync as patches.
- Player position, rotation, speed and grounded state sync during PC/VR playtests. Remote Gorilla avatars hide when their owner exits playtest.
- Coloured editor cursors show the surface each collaborator is pointing at while building.
- The room stores the latest shared project snapshot while the server is running.
- If two users change the same object simultaneously, the latest arriving update wins. Different objects can be edited concurrently. New object IDs are namespaced per room member to avoid simultaneous-add collisions. The shared scene is patched live; a joiner downloads the room snapshot when entering.
- Imported assets are included in shared data when required. Very large individual room packets are capped at 28 MB.

PRIVACY / ROOM SAFETY
---------------------
Room codes are random invite codes. Only share them with people you intend to invite. Use nicknames rather than personal details. There is no voice chat in this version. Use a room code only with people you intend to invite.

IMPORTANT
---------
itch.io can distribute the game files, but it does not run custom multiplayer server code for your game. The multiplayer server must run separately on your PC/LAN or a WebSocket hosting provider.
