/* GTAG Unity updater: fixed public repository, launch check + five-minute polling. */
(function(){
 const $=id=>document.getElementById(id); if(!$('checkUpdate'))return;
 const REPOSITORY='thomasolt/-GTag-unity-official';
 const CHECK_EVERY_MS=5*60*1000;
 let latest=null,checking=false,lastCheckedAt=0;
 async function api(path,opts){const r=await fetch(path,Object.assign({cache:'no-store'},opts||{}));let j={};try{j=await r.json();}catch(e){}if(!r.ok)throw new Error(j.error||('Request failed ('+r.status+')'));return j;}
 function status(msg){$('updateStatus').textContent=msg;}
 async function check(showToast){
  if(checking)return;checking=true;lastCheckedAt=Date.now();
  $('checkUpdate').disabled=true;
  if(!latest||!latest.updateAvailable)$('installUpdate').hidden=true;
  status('Checking for updates from the official GTAG Unity repository…');
  try{
   const r=await api('/api/update/check?repo='+encodeURIComponent(REPOSITORY));latest=r;
   if(r.releaseUrl){$('releaseLink').href=r.releaseUrl;$('releaseLink').textContent='View '+r.latestVersion+' release notes';$('releaseLink').hidden=false;}
   $('installUpdate').hidden=!r.updateAvailable;
   if(r.updateAvailable)status('Update available: '+r.latestVersion+'. Select Install update when you are ready. Automatic check every 5 minutes.');
   else status('You are up to date ('+r.currentVersion+'). Automatically checking every 5 minutes.');
  }catch(e){status('Automatic update check failed: '+e.message+'. It will retry in 5 minutes.');}
  finally{$('checkUpdate').disabled=false;checking=false;}
 }
 async function install(){if(!latest||!latest.updateAvailable)return;if(!confirm('Install GTAG Unity '+latest.latestVersion+' now? The app will restart. Your saved projects are stored in this browser and are not part of the update.'))return;
  $('installUpdate').disabled=true;status('Preparing update… keep this window open.');
  try{await api('/api/update/install',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({repository:REPOSITORY})});status('Update started. Waiting for the app to restart…');$('installUpdate').hidden=true;let tries=0;
   const waitForRestart=setInterval(async()=>{tries++;try{await api('/api/update/config');clearInterval(waitForRestart);status('Update installed. Reloading GTAG Unity…');setTimeout(()=>location.reload(),500);}catch(e){if(tries>90){clearInterval(waitForRestart);status('The update is taking longer than expected. Close this window and run START_BUILDER.bat again.');}}},1500);
  }catch(e){status('Could not start update: '+e.message);$('installUpdate').disabled=false;}
 }
 $('checkUpdate').addEventListener('click',()=>check(true));$('installUpdate').addEventListener('click',install);
 // Check immediately when the project hub appears, then poll every five minutes.
 check(false);setInterval(()=>{if(document.visibilityState==='visible')check(false);},CHECK_EVERY_MS);
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&Date.now()-lastCheckedAt>=CHECK_EVERY_MS)check(false);});
})();
