# Local server for the GTag Unity.
# - always uses its own address (http://127.0.0.1:8642) so it can't mix with
#   other servers on "localhost:8000", and your browser saves stay in one place
# - never lets the browser cache files, so new versions always show up
# - serves .js with the right type (some Windows PCs get this wrong)
# - written to run on very old Python 3 versions too (3.1 and up)
import sys
if sys.version_info[0] < 3:
    print('This builder needs Python 3, but this computer started Python ' + sys.version.split()[0] + '.')
    print('Install Python 3 from python.org (tick "Add python.exe to PATH"), then try again.')
    try:
        raw_input('Press Enter to close...')
    except Exception:
        pass
    sys.exit(1)
import os, socket, threading, webbrowser, subprocess, json, re, time
import http.server, socketserver
try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen
try:
    from urllib.parse import parse_qs
except ImportError:
    from urlparse import parse_qs
APP_VERSION = '1.0.2'
DEFAULT_UPDATE_REPO = 'thomasolt/-GTag-unity-official'
HTTP_SERVER = [None]


QUEST = '--quest' in sys.argv          # START_FOR_QUEST.bat: also let your Quest (same Wi-Fi) open it
NO_BROWSER = '--no-browser' in sys.argv
APP_MODE = ('--app' in sys.argv) or ('--builder' in sys.argv)  # standalone Edge/Chrome app window
HOST = '0.0.0.0' if QUEST else '127.0.0.1'
PORTS = (8642, 18642, 28642, 38642)
os.chdir(os.path.dirname(os.path.abspath(__file__)))


def lan_ip():
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))   # no data is sent, this just picks the Wi-Fi/LAN address
        return s.getsockname()[0]
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return 'YOUR-PC-IP'
    finally:
        if s is not None:
            s.close()


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = dict(http.server.SimpleHTTPRequestHandler.extensions_map)
    extensions_map.update({'.js': 'text/javascript', '.mjs': 'text/javascript',
                           '.glb': 'model/gltf-binary', '.json': 'application/json',
                           '.otf': 'font/otf', '.png': 'image/png', '.jpg': 'image/jpeg',
                           '.html': 'text/html', '.css': 'text/css',
                           '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.m4a': 'audio/mp4', '.webp': 'image/webp', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml'})

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, must-revalidate')
        # Explicitly allow immersive WebXR sessions for this same-origin local app.
        self.send_header('Permissions-Policy', 'xr-spatial-tracking=(self), fullscreen=(self)')
        http.server.SimpleHTTPRequestHandler.end_headers(self)

    def log_message(self, *args):
        pass

    def send_json(self, code, payload):
        body = json.dumps(payload).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith('/api/update/config'):
            cfg_path = os.path.join(os.getcwd(), 'update_config.json')
            try:
                f = open(cfg_path, 'r')
                try: cfg = json.loads(f.read())
                finally: f.close()
            except Exception:
                cfg = {'repository': DEFAULT_UPDATE_REPO}
            self.send_json(200, {'repository': cfg.get('repository') or DEFAULT_UPDATE_REPO})
            return
        if self.path.startswith('/api/update/check'):
            try:
                query = self.path.split('?', 1)[1] if '?' in self.path else ''
                repo = parse_qs(query).get('repo', [''])[0]
                if not re.match(r'^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$', repo):
                    raise ValueError('Enter a valid public GitHub repository as owner/repository.')
                req = Request('https://api.github.com/repos/' + repo + '/releases/latest', headers={'Accept':'application/vnd.github+json','User-Agent':'GTAG-Unity-Updater'})
                response = urlopen(req, timeout=15)
                try: release = json.loads(response.read().decode('utf-8'))
                finally: response.close()
                assets = release.get('assets') or []
                asset = None
                for item in assets:
                    name = item.get('name', '')
                    if name.lower().endswith('.zip') and 'gtag_unity' in name.lower():
                        asset = item
                        break
                if not asset:
                    raise ValueError('The latest GitHub Release has no GTAG_Unity ZIP asset. Upload the app ZIP as a release asset first.')
                tag = str(release.get('tag_name') or '').lstrip('vV')
                # Some early releases were published with a generic tag such as 'Release'.
                # Fall back to the release title so 'GTag unity 1.0.0' is parsed as 1.0.0.
                title = str(release.get('name') or '')
                version_text = tag if re.search(r'\d+(?:\.\d+){1,2}', tag) else title
                match = re.search(r'\d+(?:\.\d+){1,2}', version_text)
                latest_version = match.group(0) if match else tag
                def version_tuple(v):
                    nums = re.findall(r'\d+', v)
                    return tuple([int(x) for x in nums[:3]]) if nums else (0,)
                available = version_tuple(latest_version) > version_tuple(APP_VERSION)
                self.send_json(200, {'currentVersion':APP_VERSION,'latestVersion':latest_version,
                    'updateAvailable':available,'releaseUrl':release.get('html_url'),
                    'assetName':asset.get('name'),'digest':asset.get('digest')})
            except Exception as e:
                self.send_json(400, {'error':str(e)})
            return
        return http.server.SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        if self.path not in ('/api/update/config', '/api/update/install'):
            self.send_error(404, 'Not found')
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length < 1 or length > 4096: raise ValueError('Invalid request size.')
            payload = json.loads(self.rfile.read(length).decode('utf-8'))
            repo = str(payload.get('repository', '')).strip()
            if not re.match(r'^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$', repo):
                raise ValueError('Enter a valid GitHub repository as owner/repository.')
            if self.path == '/api/update/config':
                f = open(os.path.join(os.getcwd(), 'update_config.json'), 'w')
                try: f.write(json.dumps({'repository':repo}, indent=2))
                finally: f.close()
                self.send_json(200, {'ok':True, 'repository':repo})
                return
            script = os.path.join(os.getcwd(), 'update_manager.py')
            if not os.path.isfile(script): raise ValueError('Update installer is missing from this app folder.')
            flags = 0
            if os.name == 'nt': flags = getattr(subprocess, 'DETACHED_PROCESS', 0x00000008) | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0x00000200)
            subprocess.Popen([sys.executable, script, '--repo', repo, '--pid', str(os.getpid()), '--app'],
                             cwd=os.getcwd(), creationflags=flags, close_fds=(os.name != 'nt'))
            self.send_json(202, {'ok':True, 'message':'Updater started; app will restart.'})
            def stop_server():
                time.sleep(0.5)
                if HTTP_SERVER[0]: HTTP_SERVER[0].shutdown()
            threading.Thread(target=stop_server).start()
        except Exception as e:
            self.send_json(400, {'error':str(e)})


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True


class QuietServer(Server):
    def handle_error(self, request, client_address):
        pass                    # browsers drop the connection after the certificate warning: not an error


def start_https():
    """Quest Browser only allows VR on https:// pages, so in Quest mode we also run an https copy."""
    cert = os.path.join(os.getcwd(), 'quest_cert.pem')
    key = os.path.join(os.getcwd(), 'quest_key.pem')
    if not (os.path.exists(cert) and os.path.exists(key)):
        return None
    try:
        import ssl
    except Exception:
        return None
    for hp in (8643, 18643, 28643, 38643):
        try:
            srv = QuietServer(('0.0.0.0', hp), Handler)
        except Exception:
            continue
        try:
            if hasattr(ssl, 'SSLContext') and hasattr(ssl, 'PROTOCOL_TLS_SERVER'):
                ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                ctx.load_cert_chain(cert, key)
                srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
            else:
                srv.socket = ssl.wrap_socket(srv.socket, certfile=cert, keyfile=key, server_side=True)
        except Exception as e:
            print('HTTPS could not start ({0}).'.format(e))
            srv.server_close()
            return None
        t = threading.Thread(target=srv.serve_forever)
        t.daemon = True
        t.start()
        return hp
    return None


def in_use(port):
    s = None
    try:
        s = socket.create_connection(('127.0.0.1', port), 0.3)
        return True
    except Exception:          # nothing answered: the port is free
        return False
    finally:
        if s is not None:
            s.close()


def main():
    if in_use(PORTS[0]):
        print('Another builder window is already running.')
        print('Close ALL other black builder windows, then start this one again.')
        input('Press Enter to close...')
        return

    server = None
    port = PORTS[0]
    for port in PORTS:
        try:
            server = Server((HOST, port), Handler)
            break
        except Exception as e:
            print('Port {0} is blocked by Windows ({1}). Trying another one...'.format(port, e))
    if server is None:
        raise RuntimeError('Windows blocked every port the builder tried. Restart the PC and try again.')
    HTTP_SERVER[0] = server
    url = 'http://127.0.0.1:{0}/'.format(port)
    if port != PORTS[0]:
        print('NOTE: using port {0} this time. Saves made on another port show up only there.'.format(port))
    print('GTag Unity is running at ' + url)
    print('Folder: ' + os.getcwd())
    print('Keep this window open while you build. Close it when you are done.')
    print('')
    if APP_MODE:
        print('PC VR (Quest Link / Air Link / Steam Link / Virtual Desktop):')
        print('  GTag Unity opens in a dedicated app window with no tabs or address bar.')
        print('  Connect the headset to this PC, then press Play in VR inside the app.')
        print('  Do not type 127.0.0.1 into the headset browser; use PC Link for PC VR.')
        print('  For standalone Quest play, use START_FOR_QUEST.bat instead.')
    if QUEST:
        https_port = start_https()
        ip = lan_ip()
        print('')
        print('=== PLAY ON YOUR QUEST (standalone) ===')
        print('Your Quest and this PC must be on the same Wi-Fi. If Windows asks about the firewall, click Allow.')
        if https_port:
            q = 'https://{0}:{1}'.format(ip, https_port)
            print('On the Quest, open the Browser and go to:   ' + q)
            print('The Quest will warn "Your connection is not private" - that is normal for a game')
            print('running on your own PC. Press  Advanced  then  Proceed  (only needed once).')
            print('Then press  Play in VR.  (VR only works on https:// addresses, not http://)')
        else:
            q = 'http://{0}:{1}'.format(ip, port)
            print('HTTPS could not start on this PC, so use the one-time Quest Browser setting instead:')
            print('  chrome://flags  ->  "Insecure origins treated as secure"  ->  Enabled, type in:  ' + q)
            print('Then open  ' + q + '  on the Quest and press  Play in VR.')
        print('(Saves on the Quest are separate from the PC: use Export project / Load to move a build over.)')
    if not NO_BROWSER:
        if APP_MODE:
            def path_candidates(names):
                # The user's older Python runtime lacks a standard executable
                # lookup helper, so search PATH manually for browser executables.
                result = []
                path_value = os.environ.get('PATH', '')
                for folder in path_value.split(os.pathsep):
                    if not folder:
                        continue
                    for name in names:
                        candidate = os.path.join(folder.strip('"'), name)
                        if os.path.isfile(candidate) and candidate not in result:
                            result.append(candidate)
                return result

            def open_app_window():
                # Prefer Edge, then Chrome. --app opens a dedicated app-style
                # window without tabs or an address bar; it retains Chromium WebXR.
                found = path_candidates(['msedge.exe', 'chrome.exe'])
                pf86 = os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')
                pf64 = os.environ.get('ProgramW6432', os.environ.get('ProgramFiles', r'C:\Program Files'))
                local = os.environ.get('LOCALAPPDATA', '')
                roots = [pf86, pf64, local]
                known = []
                for root in roots:
                    if root:
                        known.append(os.path.join(root, 'Microsoft', 'Edge', 'Application', 'msedge.exe'))
                        known.append(os.path.join(root, 'Google', 'Chrome', 'Application', 'chrome.exe'))
                for path in known:
                    if os.path.isfile(path) and path not in found:
                        found.append(path)
                for exe in found:
                    try:
                        subprocess.Popen([exe, '--new-window', '--app=' + url], close_fds=True)
                        print('Opened GTag Unity in its standalone app window: ' + exe)
                        return
                    except Exception as e:
                        print('Could not start {0}: {1}'.format(exe, e))
                print('Could not find Microsoft Edge or Google Chrome.')
                print('Install or repair Edge/Chrome, then run START_BUILDER.bat again.')
                print('The local server is still running at ' + url)
            threading.Timer(0.9, open_app_window).start()
        else:
            threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    try:
        main()
    except SystemExit:
        raise
    except BaseException:
        import traceback
        err = traceback.format_exc()
        print('')
        print('Something went wrong while starting the builder:')
        print(err)
        try:
            f = open('builder_log.txt', 'w')
            f.write(err)
            f.close()
        except Exception:
            pass
        try:
            input('Press Enter to close...')
        except Exception:
            pass
        sys.exit(1)
