@echo off
title GTAG Unity Multiplayer Server
cd /d "%~dp0multiplayer-server"
if not exist "%~dp0multiplayer-server\server.py" (
  echo Multiplayer server files are missing. Re-extract the complete GTAG Unity ZIP.
  pause
  goto :eof
)
set PYCMD=
py -3 -c "import sys" >nul 2>nul && set PYCMD=py -3
if not defined PYCMD ( python -c "import sys; sys.exit(0 if sys.version_info[0]==3 else 1)" >nul 2>nul && set PYCMD=python )
if not defined PYCMD ( python3 -c "import sys; sys.exit(0 if sys.version_info[0]==3 else 1)" >nul 2>nul && set PYCMD=python3 )
if not defined PYCMD (
  echo Python 3 was not found. Install Python 3 and enable Add Python to PATH.
  pause
  goto :eof
)
set "DATA_DIR=%~dp0multiplayer-server\data"
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"
%PYCMD% server.py
if errorlevel 1 (
  echo.
  echo Multiplayer server stopped with an error.
  pause
)
