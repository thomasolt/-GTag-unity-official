@echo off
title GTag Unity (Quest)
cd /d "%~dp0"
if not exist "%~dp0serve.py" (
  echo.
  echo  It looks like you opened this from INSIDE the zip file.
  echo  Close this, right-click the GTag_Unity zip, pick "Extract All...",
  echo  then open START_FOR_QUEST.bat from the folder that comes out.
  echo.
  pause
  goto :eof
)
set PYCMD=
rem use Python 3 (some PCs also have the old Python 2, which can't run this)
py -3 -c "import sys" >nul 2>nul && set PYCMD=py -3
if not defined PYCMD ( python -c "import sys; sys.exit(0 if sys.version_info[0]==3 else 1)" >nul 2>nul && set PYCMD=python )
if not defined PYCMD ( python3 -c "import sys; sys.exit(0 if sys.version_info[0]==3 else 1)" >nul 2>nul && set PYCMD=python3 )
if not defined PYCMD (
  echo Python 3 was not found. Install Python 3 from python.org - tick "Add python.exe to PATH" - then try again.
  pause
  goto :eof
)
%PYCMD% serve.py --quest
if errorlevel 1 (
  echo.
  echo  The builder stopped with an error. Take a photo/screenshot of this window and send it to Claude.
  echo  The same text was saved to builder_log.txt in this folder.
  pause
)
