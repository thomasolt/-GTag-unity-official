@echo off
rem Compatibility alias: both desktop launchers open the standalone app window.
call "%~dp0START_BUILDER.bat"
