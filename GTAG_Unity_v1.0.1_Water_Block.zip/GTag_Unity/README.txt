GTAG UNITY — 1.0.1   (was "Backrooms Asset Placer")
A Gorilla Tag game maker launched as a dedicated desktop app window on Windows. Build maps,
place lobby props, playtest on PC or in VR as the gorilla, then export everything as a .glb.

WHAT'S NEW IN 1.0.1 — WATER BLOCK + GTAG-STYLE MONKE MART CASHIER
- Added a Water block to the Blocks section of the Asset Library. Drag it into the map or click it to place a translucent blue water volume with subtle animated ripples.
- Water is a non-solid visual volume in PC playtests, so players can pass through it; swimming physics are not included yet.
- Replaced the old imported cashier character with Milo, a low-poly Gorilla Tag-style monke built on the editor's existing long-arm rig.
- Added a two-tone cap with an M coin badge and a small MILO / STAFF name tag attached to the head and torso bones.
- The cashier now idles with a subtle breathing bob and head movement, and gives a small nod when the shop is opened.
- Kept the existing Monke Mart kiosk, display shelves, checkout screen, E interaction, cosmetic catalogue, 750 test-coin starting balance and saved purchases.
- Kept the fixed-repository updater and five-minute automatic update checks. Updates still require the player to choose Install update.

0.9.21 FIX: Face-pack and painted-face textures now use TextureLoader orientation instead of incorrectly inheriting the GLB material flipY flag. This fixes the upside-down face on monster meshes while leaving the face-picker thumbnails unchanged.

0.9.22 UPDATE: Exact-position copy / paste. Ctrl+C, Ctrl+X, Ctrl+V and Duplicate now preserve
an object's exact position, rotation and scale instead of moving it to the mouse or offsetting it.
Selected map parts can also be copied as independent GLB-backed objects, so they can be duplicated
without changing the source map. Multi-selection, custom models, blocks, monster settings, textures,
animations and object scripts are carried across. Move the pasted selection afterwards if you want
another position.


WHAT'S NEW IN 1.0.1 — AUTOMATIC UPDATES + SEPARATE MONKE PARTS + PROJECT HUB + GROUP SELECTION
- The official public update repository is built into the app: thomasolt/-GTag-unity-official. No repository entry, GitHub login or token is needed.
- The launcher checks on startup and every five minutes while it is open and visible. It also checks after the app becomes visible again if five minutes have elapsed. Updates require a player to click Install update; they are not silently installed.
- The GTag Monke — Separate Parts asset spawns 14 independently selectable pieces cut from the supplied rigged model: head, torso, upper arms, forearms, hands, index fingers, middle fingers and thumbs. Pieces preserve source materials and skin/armature data and can be repositioned individually or as a group. The supplied source model has no separate ring/pinky geometry.
- The update checker now lives beside the project list, with Check for updates, Install update, release notes and update history visible on the project-selection screen.
- Hold Shift and click objects in the viewport or Scene Hierarchy to add/remove them from the current selection.
- A shared gizmo moves, rotates and scales the entire selection together.
- Use the Copy group / Paste group buttons or Ctrl+C / Ctrl+V. Copies preserve each object's transform and relative spacing; the pasted group stays selected so you can move it as one.
- Duplicate also duplicates the whole current selection. Group copy supports placed props, monsters, blocks, imported models, editable map parts, textures, scripts, animation data and saved light settings where available.

WHAT'S NEW IN 1.0.1 — CUSTOM PORTAL + STATIC GLOW + MODELER STUDIO
- Portal interiors are now a single flat, solid colour. The animated gradients, shimmer bands, moving glow and particles are removed. The selected portal colour remains editable; the frame and nearby point light still glow in the matching colour.
- Added GTAG Modeler Studio as a dedicated workspace reachable from the main toolbar.
- Modeler supports primitive creation (cube, sphere, cylinder, cone, torus), GLB import/export, object move/rotate/scale, editable vertex mode, material colour/roughness, hierarchy selection and deletion/duplication.
- Added armature creation, named root/child bones, bone hierarchy selection and visible skeleton guides. Meshes can be bound to the armature using automatic distance-based skin weights, then exported as skinned GLB.
- Added direct Send to Animator handoff. The model, armature and skin weights are transferred into Monster Animator as a new project, with a blank starter clip ready for keyframing. The Animator continues to import standard rigged GLB files as before.
- Modeler and Animator remain local to the same GTAG Unity app origin. Use Export GLB regularly as a portable model backup.
- Limitations: this is a lightweight Blender-style modelling/rigging workspace, not a full Blender replacement. It currently has primitive/vertex editing and automatic weights, but not sculpting, UV painting, texture baking, modifier stacks or manual per-vertex weight painting. Existing imported GLB rigs are preserved on import; complex rigs should be checked in the Animator before production use.

WHAT'S NEW IN 1.0.0 — FIRST PUBLIC RELEASE + IN-APP UPDATER
- Consolidated the app version to 1.0.0.
- Added an Updates panel beside the project list in the project launcher. The repository is fixed to the official public source; no manual setup is required.
- The app checks the latest published GitHub Release and compares version numbers.
- If a newer release contains a GTAG_Unity ZIP asset, Install update downloads it, verifies the SHA-256 digest supplied by GitHub, backs up the current app folder, applies the update, and restarts the local app server.
- Project saves remain in the browser's local IndexedDB storage; the updater does not delete browser data. Existing local Quest certificate files and the saved update-repository setting are preserved.
- A dated backup folder is created beside the app before an update is applied.
- The initial public release was published in the configured repository using the tag "Release" and a title containing "GTag unity 1.0.0". The version checker can read that initial release title. For future releases, use a normal version tag such as v1.0.3 and attach a ZIP whose filename contains "GTAG_Unity". Keep the repository public so friends can check releases without signing in.
- No GitHub account password or repository credentials are stored in the app; the public release API is used to check versions.

START: double-click START_BUILDER.bat or START_APP.bat to open the standalone desktop app window (no tabs or address bar), or START_FOR_QUEST.bat for standalone Quest VR.



WHAT'S NEW IN 0.9.23.4 — LIGHT DUPLICATION + WEBXR STARTUP FIX
- Ctrl+C / Ctrl+V and Ctrl+D now copy a light object's saved configuration as well as its transform: colour, intensity, range, spot angle and shadow setting. Newly pasted lights are restored with the same configuration instead of reverting to defaults.
- WebXR immersive-session requests are now made immediately from the Play in VR click handler. The old flow awaited isSessionSupported() first, which could consume the transient user activation required to request an immersive session.
- local-floor is explicitly requested because the Gorilla locomotion code uses floor-relative tracking. DOM overlay, bounded-floor and hand-tracking remain optional.
- VR errors now report actionable causes (no runtime, insecure URL, existing session, or focus/permission issue). A small status indicator checks whether the browser currently detects an immersive VR runtime; it never blocks the click-to-enter flow.
- Service-worker cache bumped to 0.9.23.4.

WHAT'S NEW IN 0.9.23.3 — PORTAL DOORWAYS + GAME MODE SHOP
- Rebuilt the shopkeeper asset as a complete low-poly retail kiosk instead of using the plain white desk alone.
- Added a deep-green / timber checkout counter with a full front fascia, decorative slats, brass trim, lower plinth and branded MONKE MART badge.
- Added a framed backboard, two three-tier product bays, display samples, NEW DROP marker, overhead shop sign and warm display lighting.
- Reused the supplied GTag monke.glb and enlarged it behind the counter.
- Posed the actual Gorilla IK rig's upper-arm, forearm and hand bones so both hands reach forward onto the checkout counter.
- Replaced the simple sign with a framed angled checkout terminal, card reader and coin tray. The PRESS E interaction and existing cosmetic purchase flow are preserved.
- Improved the checkout screen typography and added a MONKE MART brand panel. All new geometry and materials are part of the placed shop object and export with the project.

WHAT'S NEW IN 0.9.23.1 — DESKTOP APP LAUNCHER + WEBXR FIX
- START_BUILDER.bat now opens a dedicated Edge/Chrome app window with no tabs or address bar.
- START_APP.bat is an alias for the same desktop app launch. The local server still runs in its console.
- Removed reliance on shutil.which(), which does not exist in the Python 3.1 installation shown in
  the startup error. Browser executable discovery now searches PATH and standard Windows install paths.
- Added an explicit same-origin WebXR spatial-tracking permissions policy to local server responses.
- Both app launchers use the local loopback origin so the editor remains a trusted context for WebXR.

WHAT'S NEW IN 0.9.23 — APP / VR / AMBIENCE / LIGHTS / SHOP / PORTALS
- Installable desktop-style app: START_APP.bat opens GTag Unity in an Edge/Chrome app window. The
  toolbar also offers Install app (or use the browser's Apps > Install this site as an app menu).
  A service worker caches the editor and bundled assets for offline startup after first load.
  START_BUILDER.bat and START_APP.bat launch a dedicated Chromium app window (no tabs/address bar) against the local server. It is an app-style desktop window, not a self-contained native EXE; Edge or Chrome provides the Chromium/WebXR runtime.
- WebXR VR: the existing Gorilla hand-push / climbing locomotion stays enabled. Left thumbstick moves,
  left grip/trigger interactions continue to work, right stick turns (SNAP or SMOOTH setting), and
  the B / Y controller button returns to the previous portal. PC VR uses Quest Link / Air Link, SteamVR,
  or another OpenXR runtime in Chrome / Edge. Standalone Quest uses START_FOR_QUEST.bat and the
  HTTPS address printed in its console; accept the local certificate warning once.
- Ambience Studio: combine Backrooms hum, drone, wind, rain, water, machinery and forest layers, or
  use Forest / Storm / Cave / Factory / Underwater / Silent presets. Import WAV, MP3, OGG or M4A loops;
  adjust each imported track, mute/remove it, and save it inside the project. Imported tracks loop from
  the beginning; trim audio externally first when you need a seamless loop. Limits: 30 MB per file,
  60 MB imported ambience per project.
- Lighting tools: add point, spot and directional lights from the new library section. Select a light
  to set colour, intensity, range, spot angle and optional shadows. Editor helper wires are hidden in playtest.
- Monke Mart cashier Milo: place the stylized GTag monke behind the checkout. Its framed checkout terminal says CHECKOUT / PRESS E TO BROWSE. The upgraded kiosk includes display shelves, a branded counter, lighting and a posed GTag Gorilla attendant.
  It opens a shop for existing cosmetics and uses local test coins (750 starting coins). Purchases are
  local project data only; there are no real-money payments or networked transactions.
- Message of the Day: select a GTag message board and use Edit message of the day in the inspector,
  or use the existing MOTD panel. Changes are saved with the project.
- Portals: place two Portal assets to auto-link them. Walking through the portal plane sends you to the
  other portal. Press B on PC, use the on-screen return button, or press B / Y on a VR controller to
  return to the last portal. Portal links are saved with the project.

PLANNED RELEASE ORDER
- v1.0.3: PCVR / SteamVR testing and fixes.
- v1.0.4: public multiplayer server deployment and persistent shared-map saving.

INSTALL / RUN
- Windows desktop app window: double-click START_BUILDER.bat (or START_APP.bat). Both launch the same standalone Edge/Chrome app window without tabs or an address bar. Keep its local-server console window open while using it.
- Standalone Quest: double-click START_FOR_QUEST.bat, keep the PC and Quest on the same Wi-Fi, open
  the HTTPS address printed in the PC console in Quest Browser, accept the local certificate warning,
  then choose Play in VR. If the Quest Browser supports WebXR DOM Overlay, checkout panels and the portal-return button appear in-headset; B/Y controller buttons are the fallback. The PC console must remain open.
- PC VR: start `START_BUILDER.bat`, connect Quest Link / Air Link / Steam Link / Virtual Desktop,
  ensure the PC OpenXR runtime is active, and press Play in VR inside the app window.

TESTING NOTE
- Static code, local-server routes, PWA manifest, app icons, service-worker precache and project-package
  integrity were checked. WebXR requires a real headset / OpenXR runtime and cannot be hardware-tested
  in this build environment. Confirm actual Quest / PC VR tracking and comfort on your device.

WHAT'S NEW IN 0.9.21 — FACE UV ORIENTATION FIX + THE QUIET RELAY
- Removed the floating circular face dome; face-pack textures now use the Gorilla model's existing shaped face surface and UVs.
- Face-picker thumbnails retain their natural image orientation; monster materials now use the correct image orientation for GLB face UVs.
- Corrected the `flipY` handling for face-pack and painted-face textures on monster meshes. Fur painting keeps its original orientation.
- Preserved the separate Timmy model's existing 180-degree UV correction.
- Added the project template THE QUIET RELAY: a liminal underground signal station with a safe entry room, corridor, maintenance room, monitoring room, signal-control room, lighting, signage, props and a custom monster called THE HUSHER.
- THE HUSHER is included in the starter project's custom-monster data and is editable in the existing Monke Maker. The intro and monster-spotted reactions use the existing Scratch-style block scripting system.

WHAT'S NEW IN 0.9.18 — MONKE MAKER + TEXTURE PAINTER
- The Monsters list now has 3 tabs: GTag monsters (default), OG monsters (Bacteria, The
  Smiler, The Crawler, The Stalker) and My monsters. Old projects with OG monsters still work.
- MONKE MAKER (My monsters > "Make a monster"): build your own monster out of the GTag monke.
  Sliders for height, head size/width/height/depth, neck length, arm length and thickness,
  hand size, body width/height/depth, distortion (lumpy, twisted mesh - "New shape" rerolls it),
  up to 3 extra heads (they twitch on their own) and up to 3 extra pairs of arms (they swing
  and flail). Pick a face from your face pack, the fur colour, how it moves, its speed and how
  chaotic it is. Live 3D preview (standing / walking / chasing / searching / jumpscare).
  "Random monster" rolls a whole new one.
- TEXTURE PAINTER (Paint fur / Paint face in the Monke Maker): brush, spray, blood splats
  with drips, darken, lighten, smear, line, colour picker, restore; fill, tint, grime and fur
  strokes for the whole texture; undo; load your own picture; save the PNG. The preview
  updates while you paint.
- Saved monsters show up under My monsters in every project (✎ edits, ✕ removes from the
  list). They're saved inside the project file too, so a shared project brings its monsters.
  Editing a monster updates the ones already placed. They chase, search and jumpscare like
  every other GTag monster.

WHAT'S NEW IN 0.9.17 — GOD + THE SUMMONING SHRINE
- GOD (Monsters): a huge grey GTag gorilla with big white feathered wings and one giant
  bloodshot eye for a face. It floats above the ground, flaps its wings, spreads its arms
  wide, and hunts you. New face "god (one big eye)".
- SUMMONING SHRINE (Props): a lava totem (dark rock with glowing cracks). In play mode, put BOTH hands
  on it for 10 seconds (just walk up to it - hands on the floor or hands up with H both work;
  in VR touch it with both hands). A bar shows the summon charging; let go and it resets.
  When it fills: white flash, a scream, and God comes down from the sky and hunts you.
  Each shrine works once per playtest. The summoned God disappears when you stop playing
  (it isn't saved into your project). You can also place God by itself without a shrine.

WHAT'S NEW IN 0.9.16 — THE EXPERIMENT FACTORY
- New project template "GTag Experiment Factory": a dark test factory with a safe break room,
  a long corridor and one wing for every monster in pain, showing what was done to it:
    01 THE HURTING - the broken tank of teal liquid it was kept in, teal spill, sample jar (its eye)
    02 HALF HEAD   - the saw chair, the head clamp, the blood, a jar with the other half
    03 NO JAW      - the pull rig still holding its torn-off arm, the snapped chain, the bite rig
  Each wing has a staff log on the wall, a broken cell, trails out the door, and a sign above
  the door. Walking into a wing in a playtest plays its log like an old tape.
- New experiments get a new wing automatically. Old factory projects get the new wing AND its
  monster dropped in the next time you open them. The sealed door at the end of the hall is
  the next experiment.
- No Jaw's arm is now torn off partway: a stump of real fur skin with a ragged torn edge and
  deep dark red flesh inside (no bone).
- Gore everywhere is now deep dark red flesh like The Hurting's face (no shiny blood, no bone).
- Long Legs and Two Heads are removed. Old projects that had them open without them.

WHAT'S NEW IN 0.9.15 — HALF HEAD + NO JAW
- HALF HEAD: a brown GTag gorilla with half of its head sliced off - wet flesh and bits of
  skull where it was, dripping blood, the one-eye face on the half that's left. Creeps after you.
- NO JAW: a grey GTag gorilla with its jaw torn away (teeth, a hanging tongue, blood all down
  its face) and its left arm ripped off at the shoulder. Limps after you on one arm, holding
  its head. Both groan and choke the whole time.
- New face: "no jaw (bloody)".

WHAT'S NEW IN 0.9.14
- Long Legs and Two Heads rebuilt to look like your pictures: light-grey GTag fur, real GTag
  heads with faces from your pack, proper long legs and arms that join the body, curved black
  claws (pale bony claws on Two Heads), and the two necks really cross in an X.

WHAT'S NEW IN 0.9.13 — LONG LEGS + TWO HEADS
- LONG LEGS: a tall light-grey GTag gorilla on two long stilt legs with black claw feet, thin
  arms hanging down to its knees with long black claws, "vamp" face from your pack.
- TWO HEADS: a thin pale gorilla with no arms, two long necks crossing in an X with a GTag head
  on each (faces "face 4" and "pbbv" from your pack), stilt legs and claw feet. The heads
  twitch on their own.
- New move style "Stilt" (long legs walking, arms hanging, claws reaching when chasing).

WHAT'S NEW IN 0.9.12
- Jolly Rancher: no crown, its three heads wear faces from your horror face pack, and the
  glowing candy colours now show the fur texture (not flat colour).

WHAT'S NEW IN 0.9.11 — JOLLY RANCHER + ICE
- JOLLY RANCHER (library > MONSTERS): three skull heads (the middle one wears a glowing crown),
  a glowing candy-coloured body: left arm green to yellow, right arm purple to pink, red body,
  blue/green/cyan heads. The side heads twitch on their own. Also as a prop (statue).
- ICE and BLUE ICE blocks (library > GTAG ASSETS) for mountain maps. They snap to the grid like
  blocks and you slide on them in the playtest (PC and VR) - blue ice is extra slippery.
  Stretch them as big as you want, the texture keeps its size.
- New face: "skull".

WHAT'S NEW IN 0.9.10 — MANY ARMS
- The Gorilla Spider is replaced by MANY ARMS (from your picture): a grey GTag gorilla with a
  long neck, two stalks growing out of its head, the red toothy "hungy" mouth from your face
  pack, and four extra arms - two of them holding blades. The arms wave around, flail when it
  chases you, and all reach for you in the jumpscare.
- Many Arms (prop): the same creature as a posed statue (GTAG ASSETS), textures included.
- The Original Monke has a real gorilla face now (heart-shaped face plate, dark eyes, nostrils).

WHAT'S NEW IN 0.9.9 — GORILLA SPIDER, SPIDER MONKE, ORIGINAL MONKE
- SPIDER MONKE: an orange GTag gorilla body on six thin wooden legs, with a white mask face
  and a red toothy mouth, head tilted. Its legs tap while it waits and skitter when it runs.
- ORIGINAL MONKE (library > GTAG ASSETS): a gorilla made only from code - no model files at
  all. Spawn it, pose it with sliders (head, arms, crouch, lean, fur colour), and press I in
  🎬 Animate to keyframe poses (they blend smoothly). "Animate bones…" opens the Monster
  Animator, which now has an "Original Monke" template too. There's also an Original Monke
  monster.
- Monster Animator: Timmy / gorilla templates now load inside the Long Fall Arcade too.
- New faces: "lurker (glowing teeth)" and "spider mask".

WHAT'S NEW IN 0.9.8 — THE HURTING
- New monster (library > MONSTERS): THE HURTING, the one-eyed teal gorilla from your
  screenshot (dark flesh face, one staring eye). It's in constant pain:
    standing still: doubled over, both hands clutching its head, shaking
    walking:        limps, dragging itself with one arm, the other hand holding its head
    searching:      rocks back and forth and hits its own head
    chasing:        lurches at you, swipes, keeps holding its head
    every few seconds a SPASM throws its body and arms backwards
  It groans in pain all the time (real recordings).
- New move style "Pain" (any gorilla monster can use it) and a new face "one eye (flesh)".
- Monster Animator: new template "The Hurting" (its rig with the teal fur and face),
  and a new chaos preset PAIN · WRITHING (also in the horror pack). Send it back to
  The Hurting and it uses your pain clip when it stands still.

WHAT'S NEW IN 0.9.7 — 🦴 MONSTER ANIMATOR
- The GTAG Animator (the one ChatGPT made, fixed) is now built in: press 🦴 Monster Animator
  in the toolbar. Pose Timmy or a gorilla bone by bone, or press Shift+G for the chaos
  generator (feral chase, searching, crawl, uncanny idle, jumpscare lunge).
- Press "➜ Send to GTag Unity", close the animator, select a gorilla monster and pick it
  under MY ANIMATION. The monster then uses your clips in the game - it picks them by name:
  CHASE..., SEARCH..., IDLE..., CRAWL/WALK..., JUMPSCARE... (missing ones fall back).
  The animation is saved inside your project.
- In the Long Fall Arcade the Monster Animator is a $2.99 expansion (Store > GTag Unity).
  In this download it's already unlocked.

WHAT'S NEW IN 0.9.6 — MORE GTAG MONSTERS, CHAOTIC MOVES
- 4 new gorilla monsters (library > MONSTERS):
  THE GLITCHED   green, stop-motion body, limbs snap to wrong angles, flickers, and
                 BLINKS a few metres toward you while it chases.
  LONG ARMS      giant arms, scrambles like a spider, grabs you from further away.
  THE MIMIC      looks like a normal lobby player (yellow, normal face) and wanders
                 around... when it sees you it turns black, its face changes and it sprints.
  THE TALL ONE   3 m tall with a stretched neck, sees very far, creeps after you.
- All gorilla monsters (Timmy and Horror Gorilla too) now have:
  CHASING   chaotic: freezes for a split second then snaps on, flailing arms, lurches
            and hops, the body wobbles, the head jerks around.
  SEARCHING hunched down, head looking around in sharp jerks, sniffing the floor,
            one hand slapping the ground in different spots.
  New CHAOS setting (0 = calm, 2 = insane) and a "Search" preview animation.
- COPY / PASTE: Ctrl+C copies, Ctrl+X cuts, Ctrl+V pastes at the exact original position,
  rotation and scale. Ctrl+D duplicates in place. Multi-selection and map parts are supported;
  map parts are copied as standalone GLB-backed objects. Textures, block colours, monster
  settings, animations and object scripts are carried over. Move the copy afterwards if needed.
- BLOCKS ON A GRID: new blocks appear where you look, lined up on a 1 m grid and
  straight (never at an angle). Look at the side of a block and the new one snaps right
  next to it, look at the top and it goes on top - easy to build walls and floors.
- FLY CAMERA FIXES (hold right mouse + WASD):
  you can now keep turning forever (the mouse is locked while you hold right-click,
  like Unity), and letting go no longer snaps the camera back or moves you up when you
  were looking up. You can also orbit from below the floor now (Alt + left mouse).

HOW TO PLAY IN VR
- PC VR (Quest Link, Air Link, Steam Link, Virtual Desktop, Steam Frame):
  1. Start START_BUILDER.bat. The builder opens in Chrome/Edge on your PC.
  2. Connect the headset to the PC (Link / Air Link / Steam Link) so you see the PC.
  3. In that SAME PC browser window press "Play in VR".
  Don't open 127.0.0.1 in the headset's own browser - there it points at the
  headset itself, so you get "page couldn't load".
  Quest Link / Air Link: in the Meta Quest app on the PC, Settings > General >
  "OpenXR Runtime" must be set to Meta Quest Link. Steam Link / Steam Frame: SteamVR
  must be the OpenXR runtime (SteamVR settings > OpenXR > Set SteamVR as OpenXR runtime).
- Quest on its own (no PC cable): START_FOR_QUEST.bat and open the https:// address
  it shows in the Quest Browser.

WHAT'S NEW IN 0.9.5 — YOUR MONSTERS, REAL SCREAMS, FLASHLIGHT, QUEST VR FIX
- TIMMY (your model) is a monster now: library > MONSTERS. He runs with his own
  "running boi" animation, or pick a new creepy one under HOW IT MOVES:
  Gallop (twitchy), Creep (hunched, head tilted, reaches out while it waits),
  Spider (head upside down), Puppet (stop-motion). Heads snap and twitch.
  Jumpscare: arms out, head shaking, right in your face.
- HORROR GORILLA: a big GTag gorilla wearing one of YOUR horror faces
  (FACE list: all 17 from your faces pack, or "Random every game"). Fur color too.
  Timmy can wear your faces as well.
- REAL SCREAMS: monster sounds are now real recordings (CC0 / public domain,
  from OpenGameArt.org - see assets/sfx/CREDITS.txt), not made-up computer noises.
  Every monster has a VOICE you can change, with a "Hear the jumpscare" button.
  Monsters also groan/breathe now and then when they're near you.
- FLASHLIGHT: library > GTAG ASSETS > Flashlight. Drag it in and it asks:
  "Should the flashlight be moved onto the Gorilla Tag head model?"
    Yes -> it's strapped on your gorilla's head. The beam goes where you look
           (PC and VR). F turns it on/off (X or A button in VR).
           Take it off: ⚙ Project > untick "Flashlight on the gorilla's head" (or Ctrl+Z).
    No  -> it's placed in the world as a prop that shines.
- QUEST VR FIX: the Quest Browser only allows VR on https:// pages. START_FOR_QUEST.bat
  now also runs an https:// address - open THAT one on the Quest (it shows it in the
  black window). The Quest warns "connection is not private": press Advanced > Proceed.
  (The certificate is a home-made one for your own PC, that's why it warns.)
- If VR can't start, the builder now tells you exactly why.

WHAT'S NEW IN 0.9.4 — EDITOR POLISH
- ⚙ Project: rename the project, see its info, and set how the player feels in it (walk speed,
  run speed, jump power, starting health, first or third person). Saved per project.
- The inspector shows what the selected thing is (block, monster, imported model, map part…), its
  id and animation keys, and a 🧩 button that opens its scripts (or makes its first one).
- The Scene Hierarchy marks objects that have scripts (🧩) or animation (◆) and uses plain
  names (BLOCK, MONSTER, ENEMY…).
- Import GLB shows progress, checks the file is really a .glb, and selects what it imported.
- Unexpected errors now show a short message instead of failing silently.
- Lighting/fog and player settings work with Undo too.

WHAT'S NEW IN 0.9.3 — MONSTERS
- New monster system. Monsters now have real states: patrol → investigate (they HEAR you run) →
  chase → search where they last saw you → back to patrol. They find their way around walls
  (pathfinding built from whatever map you load, custom maps too), sidestep when stuck, and
  never enter safe zones. Positional sounds: you hear which side they're on.
- Bacteria: smarter, glossy black with pin-prick eyes, a smoky aura and glitching while it chases.
- The Smiler: waits in the dark, watching you with its glowing grin. Stare at it too long (or get
  close) and it comes for you.
- The Crawler: pale and spider-like, low to the ground, fast and erratic, skitters, screeches.
- The Stalker: tall and faceless with red eyes. It follows you from behind, hides around corners
  when you turn to look, and builds tension until it attacks.
- Select a monster to set it up under MONSTER: enabled, how far it sees, how far it hears running,
  walk / chase speed, health (0 = can't die; otherwise you can shoot it), spawn radius (random
  start spot), what happens when it catches you (jumpscare, or hurt the player's health),
  damage, the Stalker's patience, and a PREVIEW of its idle / walk / chase / attack animation.
- The 3D Horror Game template now has all four monsters.
- "when an enemy sees the player" / "when an enemy dies" script blocks fire for monsters too.

WHAT'S NEW IN 0.9.2 — 🧩 SCRIPTS (SCRATCH-STYLE BLOCKS)
Make game logic without writing code. Press 🧩 Scripts.
- ＋ New script makes a script for the selected object (or the World if nothing is selected).
  "Runs on" changes it. Drag blocks from the left, snap them under each other or into the mouth of
  if / repeat / forever. Round blocks (numbers) and pointy blocks (true/false) drop into the holes
  inside other blocks. Drag a block back to the left, or right-click it, to delete it.
- Categories: Events (game starts, player spawns, object clicked, player touches object, enemy sees
  the player, every X seconds, key pressed, fire pressed, enemy dies, player dies), Player, Combat
  (gun, fire, reload, damage, ammo), Enemies (spawn, follow/chase/patrol, attack, health, speed,
  destroy), Logic (if, if/else, repeat, forever, wait, compare, and/or/not), Math, Health, Audio
  (sound effects + music made in the browser), World (spawn/destroy/move/show/hide/color objects,
  lighting, fog, on-screen messages) and Variables (with an on-screen display).
- The blocks really run in the playtest (PC and VR): a health bar, ammo counter, crosshair and your
  variables show on screen. In VR the right trigger fires.
- New "Enemy" in the library (Monsters & Zones): a robot that patrols and shoots back.
- The 3D Shooter Game template now comes with a full game made of blocks: a gun, waves of robots,
  score, reload on R, win at 10, death and respawn. Open its 🧩 Scripts to see how it works.
- Scripts are saved with the project, in exported scenes, and work with Undo.

WHAT'S NEW IN 0.9.1 — PROJECTS
- GTag Unity now opens on a project launcher (like Unity Hub):
  ＋ New project, open a project, recent projects with a preview picture, Rename, Delete,
  and "Open project file…" to bring in a project .json (from Export project).
- Templates: Empty 3D Project (flat ground, daylight), 3D Horror Game (dark backrooms, fog,
  flashlight, monster, safe zones), 3D Shooter Game (walled arena with cover, platform and ramp),
  GTag Backrooms Lobby (the lobby you had).
- Every project has its own map, objects, textures, animations, settings, autosave and manual
  save. Opening one never touches another.
- ☰ Projects (top bar) saves and goes back to the launcher.
- Your work from before 0.9.1 was moved into a project called "My Backrooms Map".

WHAT'S NEW IN 0.9.0 — REPLACE MAP FIXED + FULL SCENE SAVE
- Replace Map now replaces the whole scene: the old map and everything placed on it are removed,
  so there is only ONE map. (Tick "Keep the objects I placed" if you want to keep your props.)
  Your old scene stays until the new one has loaded. If loading fails, nothing changes.
  Ctrl+Z (or "↶ Undo last replace") brings the old scene back.
- If the .glb was exported from GTag Unity, its computer, leaderboard, mode select, wardrobe,
  mirrors, blocks, monsters and spawn come back as real working objects (not frozen copies),
  and the gorilla preview is skipped.
- Export GLB has "Save the GTag Unity scene inside". With it on, Replace Map brings the scene back
  EXACTLY: every object, transform, block color, texture, animation + keys, hidden parts,
  lighting, fog and the spawn. The .glb still opens normally in Blender / Unity.
- 🌫 Scene: lighting and fog settings (dark backrooms or bright daylight, fog color and distance,
  lamp and flashlight brightness, exposure). Saved with your project and in exported scenes.
- Better messages while loading big maps, and a clear error if a file isn't a .glb.

WHAT'S NEW IN 0.8 — ANIMATOR
Press 🎬 Animate to open the timeline at the bottom.
  1. Select something you placed (a block, a prop, a model you imported).
  2. Press I (or ◆ Key) to save its pose at the current time.
  3. Click/drag on the timeline to another time, move/rotate/scale the object, press I again.
  4. Press ▶ (or Space) to watch it. Drag the blue playhead to scrub.
- Keys show as diamonds (gold = selected object). Click a diamond to jump to it, Delete key removes it,
  Clear removes all of that object's keys.
- Length (seconds), Loop, and Ease (Smooth or Linear) are in the bar.
- "Play in game": the animations run when you playtest on PC and in VR. Standing on something
  that moves (an elevator, a moving platform) carries you with it.
- Export GLB includes the animation, so it plays in Blender / Unity too.
- Tip: if you move an animated object without pressing I, it jumps back when you move the
  playhead (just like Blender). Press I to keep the change.

WHAT'S NEW IN 0.7
- Add Block, like Blender: press Shift+A on the map (or the ＋ Add button) and pick
  Cube, Plane, Cylinder, Sphere, Cone, Ramp, Stairs, Arch, Wall or Pillar. It appears where your mouse is.
  They're also at the top of the Asset Library.
- Blocks are 1 m (walls 2 x 2.5 m), sit on the floor, and you collide with them on PC and in VR,
  so you can build whole maps out of them.
- Pick a block's color under TRANSFORM (BLOCK COLOR), or put a texture on it (it tiles like the walls).
- Scale them with R, copy them with Ctrl+D, undo with Ctrl+Z.

WHAT'S NEW IN 0.6
- Renamed to GTag Unity. Your old saves still load.
- Undo / Redo: Ctrl+Z undoes, Ctrl+Y (or Ctrl+Shift+Z) redoes. Also the ↶ ↷ buttons.
  Works for moving, rotating, scaling, hiding, deleting (map parts too), textures and adding things.
- Autosave: a few seconds after every change your scene saves itself in this browser
  ("✓ Autosaved" in the top bar). When you open GTag Unity again you're right where you left off.
  Save / Load still keep a separate manual save, and Export project still makes a backup file.

WHAT'S NEW IN 0.5.3
- The launcher works on very old Python 3 versions too (like Python 3.1).

WHAT'S NEW IN 0.5.2
- The launcher picks Python 3 even if the old Python 2 is also installed.

WHAT'S NEW IN 0.5.1
- The launcher no longer closes by itself. If something goes wrong it stays open, shows the error
  and saves it to builder_log.txt. It also warns you if you opened it from inside the zip.
- If Windows blocks port 8642 (this can happen after a restart) it uses a backup port.

WHAT'S NEW IN 0.5 — VR MODE
Press  🥽 Play in VR  to play your map as a real Gorilla Tag gorilla:
- Move with your arms like GTag: hands stick to whatever they touch, push off the floor or walls
  to move, let go to fling yourself. Push down hard to jump. Climb walls the same way.
- Right thumbstick turns. Pick SNAP / SMOOTH / NONE and the speed on the computer's TURN page.
- Press the keyboard keys and the screen buttons (mode squares, mute/report, computer menu) with
  your finger. You feel a buzz in the controller when you touch something.
- The gorilla body follows your head and its arms follow your hands. The bacteria still hunts you.

HOW TO GET INTO VR
A) PC VR (Quest Link, Air Link, Steam Link or any SteamVR headset) — easiest, best graphics:
   1. Connect your headset to the PC (Link / Air Link / Steam Link) so you're in the PC VR home.
   2. Start START_BUILDER.bat as usual. It opens in Chrome or Edge on the PC.
   3. Press  Play in VR  (in the headset you can see the PC screen to click it).
B) Standalone Quest (no PC in the headset, same Wi-Fi):
   1. Start START_FOR_QUEST.bat instead. It prints an address like http://192.168.1.20:8642
   2. One time only, in the Quest Browser: go to chrome://flags, search "insecure origins",
      set "Insecure origins treated as secure" to Enabled, type that address in the box, Restart.
   3. Open the address in the Quest Browser and press  Play in VR.
   The Quest gets lighter graphics automatically (no shadows, fewer lamps, mirrors off) so it runs
   smoother. Saves on the Quest are separate from the PC (move builds with Export project / Load).
This is the browser version. The real Quest APK (for Venture / Steam Frame / sideloading) is next,
and it will use the same movement.

WHAT'S NEW IN 0.4.3
- Key letters now line up straight with each key.

WHAT'S NEW IN 0.4.2 (screens restyled from real GTag screenshots)
- Computer: menu down the left (ROOM, NAME, COLOR, TURN, MIC, QUEUE, CREDITS) with "<-" on the open page,
  key words in yellow. UP/DOWN arrow keys change page (or click a menu item).
    ROOM   type a code + ENTER to join/create that room (empty = random code). OPTION 1 = leave.
    NAME   type + ENTER.   COLOR  OPTION 1/2/3 pick red/green/blue, then 0-9 sets it.
    TURN / MIC / QUEUE  OPTION 1/2/3 pick a setting (saved, ready for the VR version).
- Keyboard: cream keys, DELETE / ENTER / OPTION 1-3 / arrow keys.
- Leaderboard: ROOM ID + GAME (players), color squares, MUTE and REPORT buttons you can press.
- Mode select: GAME MODES list with square buttons (red = picked), click one to pick it.
  The CURRENT MODE panel says -NOT IN ROOM- until you join a room.
- Message board: big MESSAGE OF THE DAY title, text wraps and shrinks to fit.
  A line written like  -- SOMETHING --  is centered.

WHAT'S NEW IN 0.4.1
- The GTag keyboard has letters printed on every key (A-Z, 0-9, DEL, ENTER, OPT 1-3, arrows).

WHAT'S NEW IN 0.4
- GTag assets (your pack, assets/gtag_assets.glb) in the library under "GTAG ASSETS":
    Computer      monitor + typing keyboard + table + stool. Click (or E) the real keys:
                  UP/DOWN change page (NAME, ROOM, MODE, COLOR), letters/numbers type,
                  DELETE erases, ENTER confirms, OPTION 1/2 do the page's extra action.
    Mode select   the stump. Its screens list the modes and show the current one; click to change.
    Message board the wall monitor: Message of the Day / update log. Press E on it to edit the text.
    Leaderboard   the stand board: player names in join order.
    Wardrobe      opens the cosmetics try-on.  Mirror / Mirror wall: live reflections.
    Stool, Table  props.
  They're scaled to fit our gorilla and turned so their front faces you when placed.
- All screens use plain white letters in the Gorilla Tag font (assets/fonts). Names on chests too.
  The font is a free Fontstruct font for non-commercial use. Keep its readme.txt and
  license.txt next to it if you share the game.
- The starter lobby layout now uses the GTag assets. If you already saved, open
  Load > Starter lobby layout to get it.

WHAT'S NEW IN 0.3
- Your map, textured. The big hall is THE BACKROOMS: yellow wallpaper, damp carpet,
  ceiling tiles and buzzing lights. The spawn room, the hallway and the small room
  inside the backrooms are SAFE ZONES: white walls with an orange band, cream floor
  tiles, a dark ceiling and round lamps.
  File: assets/backrooms_map_textured.glb (the textures are also in assets/textures).
- Fangame lighting in playtest: dark, with real lamp light, flickering lamps and fog
  in the backrooms. "Game light" in the toolbar previews it while you edit.
- 0.3.2: a flashlight on the camera puts a soft circle of light wherever you look
  (like the fangame).
- Names on chests in chunky white letters. Test players in the lobby show up as
  coloured gorillas with their names, standing around the spawn and looking at you.
  Pick your own gorilla colour on the computer.
- THE BACTERIA: a tall, thin, twitching entity that roams the backrooms.
    It spots you if it can see you, or hears you sprinting nearby.
    It's faster than walking but slower than sprinting (Shift).
    It can't enter safe zones. Get inside one and it gives up.
    If it catches you: jumpscare, then back to the spawn.
  Add more from "MONSTERS & ZONES" in the library.
- Safe zone boxes: the map's safe zones show as green boxes while editing. You can
  place your own "Safe zone" boxes and scale them. They're invisible while playing.
- The top-right corner shows SAFE ZONE / THE BACKROOMS while you play.
- First start loads your lobby layout (computer, leaderboard, mirror, mode switcher,
  cosmetics, stand, spawn, one Bacteria and 3 test players). After you Save, your
  own save is used instead.
- Sound is made in code: lamp hum, the Bacteria's footsteps, a chase drone and the scream.

WHAT'S NEW IN 0.2
- Import GLB: toolbar button, the "Import GLB..." card, or drag .glb files onto the map.
- Export GLB: whole scene or only what you selected. You can include or leave out the map,
  the gorilla, and hidden things. Object names are kept, and each object's type
  (computer, leaderboard...) is saved in the glTF extras for Unity/Blender.
- Replace map: load your expanded map .glb. Your props and spawn stay where they are.
- Hide things like Blender:
    H            hide selected
    Shift+H      hide everything else (isolate)
    Alt+H        unhide everything
    eye icons    in Scene Hierarchy, for any object or single map part
    Hide ceilings  button in Scene Hierarchy: removes roofs so you can see inside
  Hiding is editor-only. Everything shows again while you playtest.
- Textures: select walls/floors/objects (Shift+click to pick several), then
  TEXTURE > Import texture... You can also drop an image file onto an object.
    "World tiling" repeats the image evenly by size in meters (best for walls/floors).
    "Model's own UVs" uses the model's UV map (best for props).
- First person playtest with an animated gorilla (IK arms):
    Hands walk on the floor (knuckle-walking, galloping run), go up when you jump,
    and reach for things you use. H switches to VR-style hands held in front.
    V switches between first and third person.
  The player now collides with walls, floors, ceilings and props.
- Cosmetics are fitted using the Halloween head models and stick to the gorilla's
  head bone, so they follow the head and show in the mirror.
  You can wear one item per slot (hat, eyes, nose, face, neck, badge, held...).
- Save keeps everything in this browser, including imported models and textures.
  Export project downloads one .json file with everything inside, for backups or another PC.

EDITOR CONTROLS
- Camera like Unity's scene view:
    Hold right mouse + WASD   fly around (mouse looks around)
    Q / E (while holding RMB) down / up
    Shift                     fly 3x faster
    Mouse wheel while flying  change fly speed
    Arrow keys                move the camera without holding a button
    Alt+LMB drag or MMB drag  orbit      LMB drag: pan      Wheel: zoom
- LMB click: select one object. Hold Shift and click to add/remove objects from the selection (viewport or Scene Hierarchy).
- W / E / R: move / rotate / scale gizmo.   F or double-click: focus selection.
- T: click-to-place. Then click a floor, wall or table to put the selected object there.
  The "Player spawn" card works the same way: click it, then click a floor.
- End: drop the selection onto the floor below it.
- Ctrl+C / Copy group: copy every selected object together. Ctrl+X: cut. Ctrl+V / Paste group: paste the whole group at the original coordinates, keeping relative spacing. The shared gizmo moves, rotates and scales the group together. Ctrl+D / Shift+D or Duplicate makes an in-place copy of the full selection.
- X or Delete: delete.   Ctrl+S: save.   P: playtest.
- The map is locked (lock icon in the hierarchy). You can select, hide and texture
  map parts, but you have to unlock it to move or delete them.

PC PLAYTEST
- Click the view to capture the mouse. Esc releases it.
- WASD move, Shift sprint, Space jump, mouse look.
- E or click: use whatever you're looking at or standing next to (computer, keyboard,
  leaderboard, mode-switcher arrows, cosmetic stand, mirror).
- V: switch first/third person. Mouse wheel zooms the third-person camera.
- Your hands walk on the floor (knuckle-walking) in first and third person.
  H lifts them up in front of you (VR style); press H again to put them back down.
- Arrow keys also change the game mode. P stops the playtest.

NOTES / LIMITS
- Online co-op now uses the included Python WebSocket room server. See ONLINE MULTIPLAYER below.
- The gorilla GLB has no animation clips. All animation is procedural (made in code with IK).
- City and Winter cosmetics don't come with head models, so they use the Halloween heads
  for size, plus a placement per slot. A few unusual items may need a small nudge.
- VR uses WebXR immersive mode with tracked Gorilla hands, controller-stick locomotion, snap / smooth turning and controller return-to-portal input. A compatible headset and secure WebXR context are required. Hardware verification is still needed on your own headset.


GTAG UNITY v0.9.23.4 LIGHT / VR FIX UPDATE
- Portals are now rectangular yellow wall-mounted doorways, matching the supplied reference style.
- Each portal includes separate THIS PORTAL and BACK physical buttons, plus an editable sign.
- Portal colour is individually editable in the inspector; new portals cycle through distinct colours.
- Pair portals automatically or select a link manually in the Portal Settings inspector.
- Game-mode switcher rows now act as coin buy/select buttons. CASUAL is free; other modes unlock with in-game test coins. These are not real-money purchases.
- Portal colour, sign label, pairing, and purchased modes are saved in the project.


WHAT'S NEW IN 0.9.23.3 — PORTAL DOORWAYS + GAME MODE SHOP
- Replaced the circular portal visual with a rectangular yellow doorway in a dark wall frame, matching the supplied reference.
- Every portal includes two separate physical buttons: THIS PORTAL and BACK. VR fingertip pokes can activate both.
- Added an editable sign above each doorway (default text: PLACE). Select a portal and edit Portal Settings in the Inspector.
- Each new portal receives a distinct colour from a palette. Select a portal and use Portal Colour to choose any custom colour. The doorway glow and button/sign accents follow that colour.
- Portals auto-pair with the nearest unlinked portal, and can be manually linked using Link to Portal in the Inspector.
- BACK returns to the exact saved player position and rotation from immediately before portal travel.
- Game-mode switcher rows now act as purchase/select buttons. CASUAL is free; INFECTION, HUNT, FREEZE TAG and SURVIVAL unlock with in-game coins.
- Prices are in-game test currency only; there are no real-money purchases. Mode ownership and portal settings are saved with the project.
- Service-worker cache version updated to 0.9.23.3.


ONLINE MULTIPLAYER — v0.9.24.1
--------------------------------
1. Double-click START_MULTIPLAYER_SERVER.bat and leave the server window open.
2. Start the editor with START_BUILDER.bat.
3. Open the 🌐 Co-op panel and click Create room.
4. Share the room code with your friend.
5. Your friend enters the same server address and room code, then clicks Join room.

The room creator's current project becomes the shared starting project. Joining replaces
your current unsaved scene, so save a backup first. Object placement, deletion, transforms,
map edits, imported assets, lighting, monsters, portals, scripts, environment, ambience
and shop data are synchronized. Coloured cursors show where the other builder is pointing.
Player Gorilla avatars synchronize while both players are in PC/VR Playtest.

SAME WI-FI: The host runs the server. Both players use ws://HOST-LAN-IP:8787/ws
(the host can use ws://127.0.0.1:8787/ws). Allow Python through Windows Firewall on a
private network when prompted.

DIFFERENT HOMES: Deploy the multiplayer-server folder to a WebSocket-capable Python host
and enter the secure wss:// URL on both PCs. Deployment notes and a Render Blueprint are
in multiplayer-server/README.txt and multiplayer-server/render.yaml. itch.io distributes
game builds but does not run your custom multiplayer server.

Up to 8 people at once and 256 join sessions per room lifetime. Each room member receives a unique object-ID namespace (up to 32,767 newly-created objects per join session), so simultaneous prop placement does not overwrite another builder's objects. The local server saves snapshots under multiplayer-server/data.
For public hosting, persistent room saves require a provider disk and DATA_DIR setting.
If two people edit the exact same object at once, the latest server update wins.
This version does not include voice chat or rollback/history for collaborative edits.


WHAT'S NEW IN 0.9.24.1 — ONLINE MULTIPLAYER + CO-OP BUILDING
- Replaced the local-only lobby placeholder with a real Python WebSocket room server.
- Create private invite-code rooms, join from another PC, and share the host's current project.
- Synchronizes object add/delete/transform, copied props, map-part edits, imported assets, lighting, monsters, portals, scripts, ambience, shop and environment settings.
- Adds coloured remote editor cursors showing where collaborators point in the map.
- Syncs player pose and Gorilla avatars during shared PC/VR playtests; remote avatars hide when a player exits playtest.
- Supports up to 8 players, host handover, reconnecting through the room code, and local room snapshot persistence.
- Includes START_MULTIPLAYER_SERVER.bat, Python standard-library server, Render Blueprint and deployment guide.
- No voice chat in this release; if two users edit the same object simultaneously, the latest arriving change wins.


GTAG UNITY v1.0.1 — CUSTOM PORTAL MODEL UPDATE
------------------------------------------------
- The portal doorway now uses the four frame/sign blocks extracted from the supplied portal and back button GLB.
- The GLB's separate button cube is used for the physical BACK control; its unrelated ground plane and Gorilla preview are not added when placing a portal.
- The editable sign, plain solid-glow surface, per-portal colours, pairing, THIS PORTAL interaction, automatic crossing and BACK return are retained.
- See UPDATE_LOG.txt for the release history.

VR LAUNCH NOTE
--------------
For PCVR through Steam Link and SteamVR, use START_BUILDER.bat and press Play in VR.
The optional START_FOR_QUEST.bat is for a Quest Browser connecting directly to the PC over a
LAN HTTPS connection; that mode needs a per-computer certificate and private key. Those
private local certificate files are intentionally not included in public release ZIPs.
